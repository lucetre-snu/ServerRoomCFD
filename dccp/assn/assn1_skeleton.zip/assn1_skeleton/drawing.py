import chart as c
import sys

command = sys.argv[1]

c.axis()

if command == "bar":
    c.bar_chart()    
elif command == "scatter":
    c.scatterplot()
elif command == "line":
    c.line_chart()
else:
    print("Wrong argument!!")

c.free_turtle()