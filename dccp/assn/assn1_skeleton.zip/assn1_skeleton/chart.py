import turtle as t

# parameters
turtle_speed = 0

# constants
AXIS_LENGTH = 500
AXIS_MARGIN = 20
AXIS_WIDTH = 3

LABELS = ["A", "B", "C", "D", "E", "F"]
COLORS = ["red", "blue", "green", "pink", "grey", "yellow"]

def axis():
    t.shape("turtle")
    t.speed(turtle_speed)
    t.width(AXIS_WIDTH)
    
    ####### Enter Your Code ########

    
    ####### End of the Code ########

def bar_chart():
    PIXEL_PER_VAL = 2.5
    ####### Enter Your Code ########
    
    
    ####### End of the Code ########


def scatterplot():
    PIXEL_PER_VAL = 5
    ####### Enter Your Code ########
    
    
    ####### End of the Code ########


def line_chart():
    PIXEL_PER_VAL = 2.5
    ####### Enter Your Code ########
    
    
    ####### End of the Code ########


def free_turtle():
    t.exitonclick()