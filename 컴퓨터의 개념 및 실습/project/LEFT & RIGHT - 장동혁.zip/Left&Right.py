###MODULE###
import pygame as p
import random as r
from collections import deque,Counter,defaultdict
from math import sin,pi,sqrt,cos
from decimal import Decimal

###COLOR PALLETE###
WHITE = (255,255,255)
WHITE_B = (190,190,220)
QUEUING = (180,180,230)
BGC = (150,150,200) # Back Ground Color
SBC = (200,200,255) # Score Background Color
CPC = (200,100,150) # Current point Color
SCC = (200,100,150)#Score Character Color
GOC = (255,100,150) #Game Over Color
GCC = (255,255,150) #Gameover Cleared Color
HTC = (255,255,200) #HearT Color
###Classes Define###
class Lane:
    '''
    의미:
    A Lane
    B Lane 
    target들이 배치되는 Queue 역할
    
    Data:
    queue = 큐에 쌓인 타겟들 - 0번째 queue는 현재 플레이 대상
    lane = 현재 lane의 id
    coin = 각 queue가 coin을 가졌는가? 1--> True / 0 --> False
    
    Method:
    next = 현재 큐가 완성되어 다음 큐로 넘어가기

    '''
    A_cord = [(20,20),(20,220),(20,420)]
    B_cord = [(370,20),(370,220),(370,420)] 
    def __init__(self,init_targets:list,lane:str):
        self.queue=deque(init_targets,3)
        self.queue[0].queue=0
        self.queue[1].queue=1
        self.queue[2].queue=2
        self.lane = lane
        
    def next(self):
        next_target=r.randint(0,1)
        if next_target == 0:
            self.queue.append(Rect(self.lane))
        elif next_target == 1:
            self.queue.append(Tri(self.lane))
        for i,v in enumerate(self.queue):
            v.queue = i

class target:
    '''
    의미:
    플레이 대상 / 삼각형과 사각형을  하위 클래스로 가짐
    -data-
    queue : Lane에서의 대기 큐
    lane : target의 lane
    target_key : 현재 눌러야 하는 키
    life : 타겟의 남은 목숨 - 0이되면 Explode
    __leng : 한 변의 길이

    -Method-    
    draw : 삼/사각형 + 꼭짓점 포인트 그리기
    correct : 생명 깎기
    '''
    def __init__(self,lane):
        self.queue = 2
        self.lane = lane
        if self.lane == 'A':
            self.target_key=p.K_q
        elif self.lane == 'B':
            self.target_key=p.K_u

class Rect(target):
    def __init__(self,lane):
        target.__init__(self,lane)
        self.life = 4
        self.__leng = 160
        self.points=deque()
    def draw(self):
        color={0:WHITE,1:QUEUING,2:QUEUING}
        width={0:3,1:1,2:1}
        if self.lane == 'A':
            self.cord=Lane.A_cord[self.queue]
        if self.lane == 'B':
            self.cord=Lane.B_cord[self.queue]

        A = self.cord
        B = (self.cord[0]+self.__leng,self.cord[1])
        C = (self.cord[0]+self.__leng,self.cord[1]+self.__leng)
        D = (self.cord[0],self.cord[1]+self.__leng)
        if len(self.points) == 0  and self.queue == 0:
            self.points=deque([A,B,C,D])
        p.draw.lines(display,QUEUING,True,[A,B,C,D],width[1])

        if len(self.points) == 4:
            p.draw.lines(display,color[self.queue],True,self.points,width[self.queue])
        elif len(self.points) == 3 or len(self.points) == 2:
            p.draw.lines(display,color[self.queue],False,self.points,width[self.queue])
        elif len(self.points) == 1:
            pass

        def draw_point(color,current_color):
            center = self.cord
            point_leng = 10
            first_cord = (center[0]-point_leng/2,center[1]-point_leng/2)
            second_cord = (center[0]-point_leng/2+self.__leng,center[1]-point_leng/2)
            third_cord = (center[0]-point_leng/2+self.__leng,center[1]-point_leng/2+self.__leng)
            fourth_cord = (center[0]-point_leng/2,center[1]-point_leng/2+self.__leng)
            point_cord=[first_cord,second_cord,third_cord,fourth_cord]
            for i in range(self.life):
                if i == self.life-1 and self.queue == 0:
                    p.draw.rect(display,current_color,[*point_cord[-i-1],point_leng,point_leng])                    
                else:
                    p.draw.rect(display,color,[*point_cord[-i-1],point_leng,point_leng])
        draw_point(color[self.queue],CPC)       
    def correct(self):
        self.life -= 1
        if len(self.points) != 0:
            self.points.popleft()
class Tri(target):
    def __init__(self,lane):
        target.__init__(self,lane)
        self.life = 3
        self.__leng = 160
        self.points = deque()
    def draw(self):

        color={0:WHITE,1:QUEUING,2:QUEUING}
        width={0:3,1:1,2:1}

        def draw_triangle(*points,back:bool = False):
            if not(back):
                if len(points) == 3:
                    p.draw.lines(display,color[self.queue],True,points,width[self.queue])
                elif len(points) == 1:
                    pass
                else:
                    p.draw.lines(display,color[self.queue],False,points,width[self.queue])
            else:
                p.draw.lines(display,QUEUING,True,points,width[self.queue])
            

        if self.lane == 'A':
            self.cord=Lane.A_cord
        if self.lane == 'B':
            self.cord=Lane.B_cord
        d = self.__leng*(1/2-1/sqrt(3))
        A=(self.cord[self.queue][0],self.cord[self.queue][1]-d)
        B=(A[0]+self.__leng,A[1])
        C=(A[0]+self.__leng/2,A[1]+self.__leng*sin(pi/3))
        self.A_B_C=[A,B,C]
        if len(self.points) == 0 and self.queue == 0:
            self.points=deque([A,B,C])
        draw_triangle(A,B,C,back=True)
        if self.queue == 0:
            draw_triangle(*list(self.points))
        else:
            draw_triangle(A,B,C)
        def draw_point(color,current_color):
            point_leng = 10
            if self.queue == 1 or self.queue == 2:
                for point2 in self.A_B_C:
                    p.draw.circle(display,color,point2,point_leng/2)
            for i,point in enumerate(list(self.points)):
                if self.queue == 0 and i == 0:
                   p.draw.circle(display,current_color,point,point_leng/2)    
                else:
                    p.draw.circle(display,color,point,point_leng/2)
            
        draw_point(color[self.queue],CPC)
    def correct(self):
        self.life -= 1
        if len(self.points) != 0:
            self.points.popleft()

class button:
    button_x = 150
    button_y = 50
    def __init__(self,name,priority):
        self.priority = priority
        self.selected = False
        self.name = name
        self.position = [_display_x/2-button.button_x/2,_display_y/2+button.button_y/2]
    def draw(self,t):
        i = 0
        if self.priority == 0:
            self.position[1] = _display_y/2+button.button_y/2-50
        elif self.priority == 1:
            self.position[1] = _display_y/2+button.button_y/2+50
        if self.selected:
            i = 1
        if self.selected == False:
            i = 0
        button_color = [(v*(3600/150-t)+c*t)/(3600/150)+g for c,v,g in zip((170,170,170),(210,210,210),[40*i,0,0])]
        p.draw.rect(display,button_color,[*self.position,button.button_x,button.button_y],1-i,border_top_right_radius=10)
        text(self.name,20,bool(i),{0:WHITE_B,1:WHITE}[i],self.position,[button.button_x/2,-button.button_y/2])
###SETTING VALUES###
'''
변수 명 앞 _는 환경변수
'''
_display_x = 550
_display_y = 600
_title = "Left, Right"
_run = True
_frame = 60

###SETTING & INITIATE###
# - 화면 세팅
p.init()
display = p.display.set_mode((_display_x,_display_y))
p.display.set_caption(_title)
# - 시간 세팅
clock = p.time.Clock()
frame = 0

# - 음향 세팅
mixer = p.mixer
mixer.init()
first_beat = mixer.Sound('sound/first.wav')
first_beat.set_volume(0.1)
other_beat = mixer.Sound('sound/other.wav')
other_beat.set_volume(0.1)
hit_sound = mixer.Sound('sound/hit_sound.Wav')
hit_sound.set_volume(0.2)
miss_sound = mixer.Sound('sound/miss.Wav')
miss_sound.set_volume(0.2)
mistake_sound = mixer.Sound('sound/mistake.Wav')
reset_sound = mixer.Sound('sound/reset.Wav')
reset_sound.set_volume(0.2)
reset2_sound = mixer.Sound('sound/reset2.Wav')
reset2_sound.set_volume(0.2)
count_sound = mixer.Sound('sound/count.Wav')
count_sound.set_volume(0.2)
count_final_sound = mixer.Sound('sound/count_final.Wav')
count_final_sound.set_volume(0.2)
###InGame Variables###
score = 0
beat_count = 0
Game_Over = False
initialized = False
target_key = {'A':None,'B':None}
key_events={}
key_up_events=defaultdict(int)
heart = 4
time_bar = _frame * 3
time_bar_max = time_bar
cleared =False
prev_pressed = []
Game_start = True
time_explode_A = 0
time_explode_B = 0
explode_shape = ''
explanation = False
###Init_condition###
A_lane = Lane([Rect('A'),Rect('A'),Rect('A')],'A')
B_lane = Lane([Rect('B'),Rect('B'),Rect('B')],'B')

current_count_A = 0
current_count_B = 0
count_key_dict_A = {1:p.K_q,2:p.K_w,3:p.K_e,4:p.K_r}
count_key_dict_B = {1:p.K_u,2:p.K_i,3:p.K_o,4:p.K_p}

start_keys=''
button_st = button('START',0)
button_st.selected=True
button_ht = button('HOW TO PLAY',1)
button_pointer = 0
###Score Management###

def clear():
    scoreboard_IO = open('score.txt','w')
    scoreboard_IO.close()
def add_score(score):
    scoreboard_IO = open('score.txt','a')
    scoreboard_IO.write(str(score)+'\n')
    scoreboard_IO.close()
def get_score():
    scoreboard_IO = open('score.txt','r')
    scores = list(map(int,scoreboard_IO.readlines()))
    scoreboard_IO.close()
    return scores
###DISPLAY FUNCTION###
def text(text:str,size:int,bold:bool,color,center,movement:list,back=None):
    text_sf = p.font.SysFont('text',size,bold)
    text_srf = text_sf.render(text,False,color,back)
    T_x = text_srf.get_rect()[2]
    T_y = text_srf.get_rect()[3]
    display.blit(text_srf,[center[0]-T_x/2+movement[0],center[1]+T_y/2+movement[1]])
def explode(lane,shape,t):
    full_time = 12
    explode_cord = [Lane.A_cord[0],Lane.B_cord[0]]
    offset = t*int(24/full_time)
    explode_color = [(c*(full_time-t)+v*t)/full_time for c,v in zip(WHITE_B,BGC)]
    if lane == 'A':
        explode_cord = explode_cord[0]
    elif lane == 'B':
        explode_cord = explode_cord[1]
    if shape == 'Rect':
        A = (explode_cord[0]-offset,explode_cord[1]-offset)
        B = (explode_cord[0]+offset+160,explode_cord[1]-offset)
        C = (explode_cord[0]+offset+160,explode_cord[1]+offset+160)
        D = (explode_cord[0]-offset,explode_cord[1]+offset+160)
        p.draw.lines(display,explode_color,True,[A,B,C,D],6-int(t*5/full_time))
    if shape == 'Tri':
        d = 160*(1/2-1/sqrt(3))
        offset = t*int(24/full_time)
        A=(explode_cord[0]-offset*cos(pi/6),explode_cord[1]-d-offset*sin(pi/6))
        B=(explode_cord[0]+160+offset*cos(pi/6),explode_cord[1]-d-offset*sin(pi/6))
        C=(explode_cord[0]+160/2,explode_cord[1]-d+160*sin(pi/3)+offset)
        p.draw.lines(display,explode_color,True,[A,B,C],6-int(t*5/full_time))
###GAME LOOP###

#Score - Data Management
scores = get_score()
if len(scores)>10:
    clear()
    scores = sorted(scores,reverse=True)
    scoreboard_IO = open('score.txt','w')
    for s in scores[:9]:
        scoreboard_IO.write(str(s)+'\n')
    scoreboard_IO.close()

while _run:

    ###Game Start###
    if Game_start:
        print('start')
        while Game_start:
            for event in p.event.get():
                if event.type == p.QUIT:
                    p.quit()
                if event.type == p.KEYDOWN:
                    start_keys=event.key
            if start_keys == p.K_UP and button_pointer == 1:
                button_st.selected=True
                button_ht.selected=False
                button_pointer = 0

            elif start_keys == p.K_DOWN and button_pointer == 0:
                button_st.selected=False
                button_ht.selected=True
                button_pointer = 1
            
            if start_keys == p.K_RETURN:
                if button_pointer == 0:
                    Game_start == False
                    break
                    
                elif button_pointer == 1:
                    explanation = True
            if explanation and start_keys == p.K_ESCAPE:
                explanation = False

            
            #3) . 1 Music & Background
            BPM=150
            intense = 40
            frame_music = int(frame%int(3600/BPM))
            BGC_dyn = p.color.Color(int(BGC[0]+intense/2-frame_music/146*intense),\
                int(BGC[1]+intense/2-frame_music/60*intense),\
                int(BGC[2]+intense/2-frame_music/60*intense))
            if frame_music == 0:
                random_type = {0:'Rect',1:'Tri'}[r.randint(0,1)]
                random_lane = {0:'A',1:'B'}[r.randint(0,1)]
                if beat_count == 0:
                    first_beat.play()
                else:
                    other_beat.play()

                beat_count += 1
                if beat_count == 4:
                    beat_count = 0
            
            display.fill(BGC_dyn)
            explode(random_lane,random_type,frame_music)
            button_st.draw(frame_music)
            button_ht.draw(frame_music)
            text('LEFT',50,True,(200,100,180),[_display_x/2-50,_display_y/2-200-25],[0,0])
            text('RIGHT',50,True,(100,200,180),[_display_x/2+50,_display_y/2-200+25],[0,0])
            text('select button with up/down keys and press ENTER to select',20,False,WHITE,[_display_x/2,_display_y/2],[0,200])
            if explanation:
                explain = p.image.load('image/explanation.png')
                display.blit(explain,[0,0])
            p.display.update()
            
            clock.tick(_frame)
            frame += 1

    ###GAME OVER###
    if Game_Over == True:
        #retry
        frame_gameover = 0
        reset_sound.play()
        while Game_Over:
            for event in p.event.get():
                if event.type == p.QUIT:
                    _run = False
                    Game_Over = False
                if event.type == p.KEYDOWN:
                    if event.key == p.K_SPACE: #Retry - Initiate
                        ###InGame Variables###
                        frame = 0
                        score = 0
                        beat_count = 0
                        Game_Over = False
                        initialized = False 
                        target_key = {'A':None,'B':None}
                        key_events={}
                        heart = 4
                        time_bar = _frame * 3
                        time_bar_max = time_bar
                        cleared = False
                        prev_pressed = []
                        time_explode_A = 0
                        time_explode_B = 0
                        explode_shape = ''
                        ###Init_condition###
                        A_lane = Lane([Rect('A'),Rect('A'),Rect('A')],'A')
                        B_lane = Lane([Rect('B'),Rect('B'),Rect('B')],'B')

                        current_count_A = 0
                        current_count_B = 0
                        count_key_dict_A = {1:p.K_q,2:p.K_w,3:p.K_e,4:p.K_r}
                        count_key_dict_B = {1:p.K_u,2:p.K_i,3:p.K_o,4:p.K_p}
                        break
                    if event.key == p.K_r:
                        clear()
                        if not cleared:
                            reset2_sound.play()
                        cleared = True
     
            ###DISPLAY _ GAMEOVER###

            text('GAME OVER',50,True,GOC,[_display_x/2,_display_y/2],[0,-100])
            if int((frame_gameover//30)%2) == 0:
                text('If you want to retry, press SPACE BAR',25,False,GOC,[_display_x/2,_display_y/2],[0,50])
                if cleared:
                    text('Score Reset : press R',20,False,GCC,[_display_x/2,_display_y/2],[0,70])
                else:
                    text('Score Reset : press R',20,False,GOC,[_display_x/2,_display_y/2],[0,70])
            else:
                text('If you want to retry, press SPACE BAR',25,False,QUEUING,[_display_x/2,_display_y/2],[0,50])
                text('Score Reset : press R',20,False,QUEUING,[_display_x/2,_display_y/2],[0,70])

            #Scoreboard
            score_list = sorted(get_score(),reverse=True)
            text('SCORE RANK',25,True,SCC,[_display_x/2,_display_y/2],[0,100])
            if len(score_list) >=6:
                score_list = score_list[0:4]
            for i,v in enumerate(score_list):
                text(str(i+1)+' : '+str(v),20,False,SCC,[_display_x/2,_display_y/2],[0,125+i*13],SBC)

            p.display.update()
            clock.tick(_frame)
            frame_gameover += 1          

    ###GAMEPLAY###
    if not initialized:
        clock.tick(5)
        for i in ['3','2','1','START!']:
            if i != 'START!':
                count_sound.play()
            else:
                count_final_sound.play()
            text(i,50,True,WHITE,[_display_x/2,_display_y/2-100],[0,0],BGC_dyn)
            p.display.update()
            clock.tick(1)
    ### 1) Input Process ###
    #1).1 events
    events=[]
    for event in p.event.get():
        if event.type == p.QUIT:
            _run = False
        if event.type == p.KEYDOWN:
            key_events[event.key] = frame
        if event.type == p.KEYUP:
            key_up_events[event.key] = frame

        events.append(event)
    #1).2 keys
    keys = p.key.get_pressed()
    target_keys=[p.K_q,p.K_w,p.K_e,p.K_r,p.K_u,p.K_i,p.K_o,p.K_p]
    key_on = {}
    IsOn = []
    for i in target_keys:
        key_on[i] = keys[i]
    for k,v in key_on.items():
        IsOn.append(v)
    IsOn = Counter(IsOn)
    ### 2) Data Update ###
    #2).1 Generate Initial Condition
    if not initialized:
        for i in range(3):
            init_target = r.randint(0,1)
            if init_target == 0:
                A_lane.queue.append(Tri('A'))
            elif init_target == 1:
                A_lane.queue.append(Rect('A'))
        for i in range(3):
            init_target = r.randint(0,1)
            if init_target == 0:
                B_lane.queue.append(Tri('B'))
            elif init_target == 1:
                B_lane.queue.append(Rect('B'))
        initialized = True
    for i,v in enumerate(A_lane.queue):
        A_lane.queue[i].queue = i
    for i,v in enumerate(B_lane.queue):
        B_lane.queue[i].queue = i
    #2).2 Target Key Assign
    current_target = (A_lane.queue[0],B_lane.queue[0])
    if isinstance(current_target[0],Rect):
        current_count_A = 4-current_target[0].life+1
    elif isinstance(current_target[0],Tri):
        current_count_A = 3-current_target[0].life+1
    if isinstance(current_target[1],Rect):
        current_count_B = 4-current_target[1].life+1
    elif isinstance(current_target[1],Tri):
        current_count_B = 3-current_target[1].life+1
    if IsOn[1] > 2: # Game Over - 3개 이상의 동시 입력
        if heart == 1:
            Game_Over=True
            mistake_sound.play()
            clock.tick(1)
            add_score(score)
            continue
        else:
            heart -= 1
            text('mistake!',20,False,(255,255,200),[_display_x/2,_display_y/2-120],[0,0])
            mistake_sound.play()
            clock.tick(2)
    else:
        if current_count_A<= 4 and current_count_B<=4:
            target_key['A'] = count_key_dict_A[current_count_A]
            target_key['B'] = count_key_dict_B[current_count_B]

        if IsOn[1] == 2:
            current_pressed = list(filter(lambda x:key_on[x] == True,target_keys))
            if keys[target_key['A']] and keys[target_key['B']]:
                time_gap = abs(key_events[target_key['A']]-key_events[target_key['B']])
                # 0~1 Perfect / 2~3 Great / 4~5 Good / 6~ No
                prev_pressed = [target_key['A'],target_key['B']]
                A_lane.queue[0].correct()
                B_lane.queue[0].correct()
                if time_gap >= 9:
                    miss_sound.play()
                elif time_gap <= 8:
                    score += int(10-time_gap/2)
                    hit_sound.play()
                    time_bar += _frame*(1-time_gap*0.1)
                time_bar_max=time_bar
            elif prev_pressed.count(current_pressed[0])==1 and prev_pressed.count(current_pressed[1]) == 1:
                pass
            else:
                if heart == 1:
                    Game_Over=True
                    mistake_sound.play()
                    clock.tick(1)
                    add_score(score)
                    continue
                else:
                    heart -= 1
                    mistake_sound.play()
                    text('mistake!',20,False,(255,255,200),[_display_x/2,_display_y/2-120],[0,0])
                    p.display.update()
                    clock.tick(2)
                    

    if A_lane.queue[0].life == 0:
        if isinstance(A_lane.queue[0],Rect):
            explode_shape_A = 'Rect'
        elif isinstance(A_lane.queue[0],Tri):
            explode_shape_A = 'Tri' 
        A_lane.next()
        time_explode_A = 12

    if B_lane.queue[0].life == 0:
        if isinstance(B_lane.queue[0],Rect):
            explode_shape_B = 'Rect'
        elif isinstance(B_lane.queue[0],Tri):
            explode_shape_B = 'Tri' 
        B_lane.next()
        time_explode_B = 12

    #2).3 Score - Speed
    if score >= 1000:
        speed = 5
    if score >=600:
        speed = 4
    elif score >=300:
        speed = 3
    else:
        speed = 1
    if time_bar <=0:
        Game_Over=True
        mistake_sound.play()
        clock.tick(1)
        add_score(score)
        continue
    ### 3) Display ###
    #3) . 1 Music & Background
    BPM=150
    intense = 40
    frame_music = int(frame%int(3600/BPM))
    BGC_dyn = p.color.Color(int(BGC[0]+intense/2-frame_music/146*intense),\
        int(BGC[1]+intense/2-frame_music/60*intense),\
        int(BGC[2]+intense/2-frame_music/60*intense))
    if frame_music == 0:
        if beat_count == 0:
            first_beat.play()
        else:
            other_beat.play()
        beat_count += 1
        if beat_count == 4:
            beat_count = 0
    display.fill(BGC_dyn)

    #3) . 2 Targets

    if time_explode_A != 12 and time_explode_B != 12:
        for targets in A_lane.queue:
            targets.draw() 
        for targets in B_lane.queue:
            targets.draw()

    #3) . 3 Score
    text('Score',20,False,SCC,[_display_x/2,_display_y/2],[0,-20])
    text(str(score),20,True,SCC,[_display_x/2,_display_y/2],[0,20])

    #3) . 4 Time Bar
    bar_x = 140
    bar_y = 20
    if time_bar<60:
        time_color = (255,0,0)
        text("HURRY!",30,True,time_color,[_display_x/2,100],[0,-50])
        text(str(int(time_bar/60)),20,False,time_color,[_display_x/2,100],[0,-20])
    else:
        time_color = WHITE
        text("Time Limit",30,True,time_color,[_display_x/2,100],[0,-50])
        text(str(int(time_bar/60)),20,False,time_color,[_display_x/2,100],[0,-20])

    p.draw.rect(display,time_color,[_display_x/2-bar_x/2,100+bar_y/2,time_bar/time_bar_max*bar_x,bar_y])
    #3) . 5 Explode
    if time_explode_A>0:
        explode('A',explode_shape_A,12-time_explode_A)

        time_explode_A -= 1
    if time_explode_B>0:
        explode('B',explode_shape_B,12-time_explode_B)
        time_explode_B -= 1
    #3) . 6 Hearts
    heart_image = p.image.load('image/heart.png')
    HT_x = heart_image.get_rect()[2]
    HT_y = heart_image.get_rect()[3]
    heart_cord = [[_display_x/2-30-HT_x/2,_display_y/2-110-HT_y/2],[_display_x/2-HT_x/2,_display_y/2-110-HT_y/2],[_display_x/2+30-HT_x/2,_display_y/2-110-HT_y/2]]
    for point in heart_cord[:heart-1]:
        display.blit(heart_image,point)

    ### 4) Update ###
    p.display.update()
    clock.tick(_frame)
    frame += 1
    time_bar -= speed
    Game_start=False
