# flappybird open source was referenced from https://code-projects.org/simple-flappy-bird-game-in-python-with-source-code/

import webbrowser
from os import error, path
from random import randint, shuffle
from pygame import Rect, display, font, image, init, mask, mixer, mouse, sprite, time, transform, event
from pygame.constants import KEYDOWN, KEYUP, K_COMMA, K_DOWN, K_ESCAPE, K_LEFT, K_PERIOD, K_RIGHT, K_UP, K_a, K_d, K_g, K_h, K_s, K_w, MOUSEBUTTONDOWN, MOUSEMOTION, QUIT, WINDOWEVENT_HIDDEN
from math import atan

print('VScode로 실행하시고자한다면, 메뉴 창의 File > Open Folder를 통해 폴더 전체를 열어주세요!')

#to do list
'''
    cf) available libraries(standard libraries) = https://docs.python.org/ko/3/library/index.html 
'''

# constants

WIN_WIDTH = 640
WIN_HEIGHT = 480
FPS = 60
PAD_X = 50
PAD_Y = 80
PAD_Y_PLAYER = 60

# font values
BLACK, WHITE, RED, GREEN, BLUE, YELLOW = (0, 0, 0), (255,255,255), (255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)
BASIC_FONT_NAME, BASIC_FONT_SIZE, BASIC_FONT_BOLD, BASIC_FONT_ITALIC, BASIC_FONT_COLOR = 'Maplestory Bold', 15, True, False, WHITE

# preset total player number is 2, to edit it later on you can change this value. 
# to add more players add control & images.  
  
TOTAL_PLAYER_NUMBER = 2
STUDY_DATA = { str(i) + 'x' + str(j) : str(i*j) for i in range(2, 10) for j in range(1, 10) }

# Direction defined for control

class Direction:
    '''
    base directions are defined as
        Direction(' '), Direction('STOP'), Direction('LEFT'), Direction('RIGHT'), Direction('UP'), Direction('DOWN')
    other directions should be the sum of base directions. 
    '''

    def __init__(self, name: str = ' '):
        self.identity = set(name.split('+'))

        for direction_stirng in self.identity:
            if not direction_stirng in [' ', 'STOP', 'LEFT', 'RIGHT', 'UP', 'DOWN']:
                raise error('Wrong Component: Direction class has limited direction components')

    def __add__(self, other):

        new_identity = set()
        
        for _ in self.identity.union(other.identity):
            new_identity.add(_)
        
        try:
            new_identity.remove('STOP')
        except:
            pass

        if len(new_identity) >= 2 :

            if 'LEFT' in new_identity and 'RIGHT' in new_identity :
                new_identity = new_identity.difference({'LEFT', 'RIGHT'})
                
            if 'UP' in new_identity and 'DOWN' in new_identity :
                new_identity = new_identity.difference({'UP', 'DOWN'})    

        if new_identity == set():
            new_identity.add('STOP')
        
        new_direction = Direction()
        new_direction.identity = new_identity

        return new_direction
    
    def __sub__(self, other): 

        other_complementary_identity = set()
        opposite_direction = {'LEFT': 'RIGHT', 'RIGHT': 'LEFT', 'UP': 'DOWN', 'DOWN': 'UP'}
        
        for direction in other.identity:
            other_complementary_identity.add(opposite_direction[direction])    

        other_complementary_direction = Direction()
        other_complementary_direction.identity = other_complementary_identity

        return self + other_complementary_direction

    def __str__(self):
        
        string = ''

        for direction_name in self.identity:
            string += '+' + direction_name

        return string.strip('+')

    def __eq__(self, other):
        
        if self.identity == other.identity:
            return True

        else:
            return False

    def __hash__(self):
        return 0

LEFT, RIGHT, DOWN, UP, STOP  = Direction('LEFT'), Direction('RIGHT'), Direction('UP'), Direction('DOWN'), Direction('STOP')

CONTROL = {'Player1': {LEFT: K_a, RIGHT: K_d, UP: K_w, DOWN: K_s, 'HOLD': K_g, 'BOOST': K_h}, 
        'Player2': {LEFT: K_LEFT, RIGHT: K_RIGHT, UP: K_UP, DOWN: K_DOWN, 'HOLD': K_COMMA, 'BOOST': K_PERIOD},
            'Command': {'QUIT': K_ESCAPE}}
EVENT_TO_CONTROL = { control: dict([ (value, key) for key, value in CONTROL[control].items() ]) for control in CONTROL }

# define Santa(=Players)

class Santa(sprite.Sprite):

    # constants that can be changed for developers
    
    TOTAL_PLAYER_NUMBER = TOTAL_PLAYER_NUMBER
    IMAGE_NAME = [ 'Santa'+ str(i) +'_Image' for i in range(1, TOTAL_PLAYER_NUMBER + 1) ] # Santa's image name - ex) Santa1_Image0
    IMAGE_HEIGHT_LIMIT = 100 # can change Santa's height to IMAGE_HEIGHT_LIMIT. the ratio of width to height will be automatically maintained.
    IMAGE_DIRECTION = RIGHT # the original direction of Santa's image file.
    DEFAULT_SPEED = 2 # must be an integer
    BOOST_SPEED = DEFAULT_SPEED * 2 # boost speed (must be an integer)
    
    # do not change these variables

    player_number = 0
    player_won = None

    def __init__(self, images):
        Santa.player_number += 1

        self.player_number = Santa.player_number
        self.font = font

        self.stop_image = images[0]
        self.walking_images = images[1:]
        self.image_ratio = Santa.IMAGE_HEIGHT_LIMIT / self.stop_image.get_height()
        self.width = self.image_ratio * self.stop_image.get_width()
        self.height = self.image_ratio * self.stop_image.get_height()
        
        self.location = [PAD_X + self.player_number*(WIN_WIDTH - PAD_X)//(Santa.TOTAL_PLAYER_NUMBER + 1) - self.width//2, 
                        WIN_HEIGHT//2 - self.height//2]
        
        self.speed = Santa.DEFAULT_SPEED
        
        self.control = CONTROL[ 'Player' + str(self.player_number) ]
        
        self.state = STOP
        if self.player_number//2 == 0:
            self.direction_left_or_right = RIGHT
        else:
            self.direction_left_or_right = LEFT
        
        self.hold = None
        self.score = 0

    @property
    def image(self):
        '''
        image is affected by the players direction and status
        if direction changes, the image must be flipped horizontally => let the original image be left, and flip it for right
        '''

        # ratio is set once, by the first Santa (Player1) created, to set the size of Santas different the code must be changed!

        if self.state == STOP:

            STOP_IMAGE = self.stop_image
            img = transform.rotozoom(STOP_IMAGE, 0, self.image_ratio)

            if self.direction_left_or_right == Santa.IMAGE_DIRECTION:
                return img
            else:
                return transform.flip(img, True, False)
            
        else:

            WALKING_IMAGE = self.walking_images
            img = transform.rotozoom(WALKING_IMAGE[ 2 * time.get_ticks() // (FPS * len(WALKING_IMAGE)) % len(WALKING_IMAGE) ], 0, self.image_ratio)
            
            if self.direction_left_or_right == Santa.IMAGE_DIRECTION:
                return img
            else:
                return transform.flip(img, True, False)
            
    @property
    def rect(self):
        return Rect(self.location[0], self.location[1], self.width, self.height)

    @property
    def mask(self):
        return mask.from_surface(self.image)

    def update(self):
        '''
        based on the player.state, player changes player.location & player.direction_left_or_right
        '''
        #input - state (direction and walking) location change

        DELTA = {STOP: (0, 0), RIGHT: (1, 0), LEFT: (-1, 0), UP: (0, -1), DOWN: (0, 1), 
                RIGHT + UP: (1, -1), LEFT + UP: (-1, -1), RIGHT + DOWN: (1, 1), LEFT + DOWN: (-1, 1) }
        
        dx, dy = DELTA[self.state]
        
        new_x = self.location[0] + dx
        new_y = self.location[1] + dy

        if PAD_X <= new_x <= WIN_WIDTH - PAD_X - self.width:
            self.location[0] = new_x
        if PAD_Y <= new_y <= WIN_HEIGHT - PAD_Y_PLAYER - self.height:
            self.location[1] = new_y

        if str(RIGHT) in self.state.identity:
            self.direction_left_or_right = RIGHT

        elif str(LEFT) in self.state.identity:
            self.direction_left_or_right = LEFT

    def hold_unhold(self, list_of_present):
        
        if self.hold == None:
            santa_x = self.location[0]
            santa_y = self.location[1] + self.height
            
            available_presents = []

            for present in list_of_present:
                
                present_x = present.location[0]
                present_y = present.location[1] + present.height
                
                

                if sprite.collide_mask(self, present) and - (present.height / 3) <= present_y - santa_y <= (present.height / 3):
                    
                    
                    if self.direction_left_or_right == LEFT:
                        distance = santa_x - present_x
                        available_presents.append((present, distance))

                    else:
                        distance = (santa_x + self.width) - present_x
                        available_presents.append((present, distance))
            
            if available_presents != []:
                nearest_present = min(available_presents, key = lambda e: e[1])[0]
                nearest_present.held = self
                nearest_present.rejected = None
                self.hold = nearest_present


        else:
            present = self.hold
            present.held = (self, self.direction_left_or_right)
            self.hold = None       

class Receiver(sprite.Sprite):

    # Receiver is coded only for 1 or 2 players. May be it can be edited to number of teams. 

    IMAGE_NAME = 'Receiver_Image' # Receiver's image name - ex) Receiver_Image0
    IMAGE_HEIGHT_LIMIT = 80

    RECEIVER_NUMBER_PER_PLAYER = 3
    TOTAL_RECEIVER_NUMBER = RECEIVER_NUMBER_PER_PLAYER * Santa.TOTAL_PLAYER_NUMBER # must be the multiple of the number of Players

    REJECT_SPEED = 5
    
    FONT_NAME = BASIC_FONT_NAME
    FONT_SIZE = BASIC_FONT_SIZE
    FONT_COLOR = BASIC_FONT_COLOR
    FONT_BOLD = BASIC_FONT_BOLD
    FONT_ITALIC = BASIC_FONT_ITALIC

    # do not change these variables

    receiver_number = 0
    created_receivers = []

    def __init__(self, font, images, data):
        Receiver.receiver_number += 1

        self.receiver_number = Receiver.receiver_number
        self.images = images
        self.image_ratio = Receiver.IMAGE_HEIGHT_LIMIT / self.images[0].get_height()
        self.width = self.image_ratio * self.images[0].get_width()
        self.height = self.image_ratio * self.images[0].get_height()
        self.image = transform.rotozoom(self.images[ randint(0, len(self.images) - 1) ], 0, self.image_ratio)
        self.location = [ PAD_X + (self.receiver_number - 1) // (Receiver.RECEIVER_NUMBER_PER_PLAYER) * (WIN_WIDTH - 2 * PAD_X - self.width), 
                        1.5 * PAD_Y + ((self.receiver_number-1) % Receiver.RECEIVER_NUMBER_PER_PLAYER) * (WIN_HEIGHT - 1.5 * PAD_Y) / (Receiver.RECEIVER_NUMBER_PER_PLAYER)]
        if (self.receiver_number - 1) // (Receiver.RECEIVER_NUMBER_PER_PLAYER) == 0:
            self.locate = LEFT
        else:
            self.locate = RIGHT
        self.data = data
        self.font = font

        Receiver.created_receivers.append(self)

    @property
    def rect(self):
        return Rect(self.location[0], self.location[1], self.width, self.height)                   

    @property
    def mask(self):
        return mask.from_surface(self.image)

    @property
    def font_surface(self):
    
        font_surface = self.font.render(self.data, True, Receiver.FONT_COLOR)
        dest = (self.location[0] + self.width / 2 - font_surface.get_width() / 2, 
                self.location[1] + self.height / 2 - font_surface.get_height() / 2 - 5)
        return font_surface, dest

class Present(sprite.Sprite):
    
    # constants that can be changed for developers
    
    IMAGE_NAME = 'Present_Image' # Presents's image name - ex) Present_Image0
    IMAGE_HEIGHT_LIMIT = 40
    
    TOTAL_PRESENT_NUMBER = 10

    FONT_NAME = BASIC_FONT_NAME
    FONT_SIZE = BASIC_FONT_SIZE
    FONT_COLOR = BASIC_FONT_COLOR
    FONT_BOLD = BASIC_FONT_BOLD
    FONT_ITALIC = BASIC_FONT_ITALIC

    # do not change these variables
    
    present_number = 0
    created_presents = []

    def __init__(self, font, images, data):
        Present.present_number += 1

        self.present_number = Present.present_number
        self.image_num = randint(0, 1)
        self.image = images[self.image_num]
        self.image_ratio = Present.IMAGE_HEIGHT_LIMIT / self.image.get_height()
        self.width = self.image_ratio * self.image.get_width()
        self.height = self.image_ratio * self.image.get_height()
        self.image = transform.rotozoom(self.image, 0, self.image_ratio)
        self.location = self.location_creator()
        self.held = None
        self.data = data
        self.font = font
        self.rejected = None
        self.tag = None

        Present.created_presents.append(self)

    @property
    def rect(self):
        return Rect(self.location[0], self.location[1], self.width, self.height)

    @property
    def mask(self):
        return mask.from_surface(self.image)

    @property
    def font_surface(self):
    
        font_surface = self.font.render(self.data, True, Present.FONT_COLOR)
        dest = (self.location[0] + self.width / 2 - font_surface.get_width() / 2, 
                self.location[1] + self.height / 2 - font_surface.get_height() / 3)
        
        return font_surface, dest

    def location_creator(self):

        finish = False
        while not finish:
            present_x = randint(PAD_X, WIN_WIDTH - PAD_X - round(self.width))
            present_y = randint(PAD_Y + Santa.IMAGE_HEIGHT_LIMIT, WIN_HEIGHT - PAD_Y - round(self.height))
            
            self.location = [present_x, present_y]

            finish = True
            if sprite.spritecollide(self, Present.created_presents + Receiver.created_receivers, False, sprite.collide_mask):
                finish = False

        return [present_x, present_y]

    def update(self):
        '''
        based on present.held, present.location changes
        '''
        if self.held:
            if type(self.held) == Santa:
                player = self.held
                player_x, player_y = player.location
                self.location = (player_x + (player.width / 2) - (self.width / 2), player_y - (self.height / 2))
            
            else: #for now self.held is a tuple of (player, player.direction_left_or_right)
                player, player_direction = self.held
                player_x, player_y = player.location
                
                if player_direction == LEFT:
                    present_x = player_x - (self.width / 2)    
                else:
                    present_x = player_x + player.width - (self.width / 2)
                present_y = player_y + player.height - self.height

                self.location = [present_x , present_y]
                self.held = None
                self.tag = player
        
        elif self.rejected:
            receiver = self.rejected

            if receiver.locate == LEFT:
                self.location[0] += Receiver.REJECT_SPEED
                if receiver.location[0] + receiver.width * 3 / 2 <= self.location[0]:
                    self.rejected = None

            else:
                self.location[0] -= Receiver.REJECT_SPEED
                if receiver.location[0] - receiver.width / 2 >= self.location[0]:
                    self.rejected = None

class Score():

    # constants that can be changed for developers

    FONT_NAME = BASIC_FONT_NAME
    FONT_SIZE = 20
    FONT_COLOR = BASIC_FONT_COLOR
    FONT_BOLD = BASIC_FONT_BOLD
    FONT_ITALIC = BASIC_FONT_ITALIC

    def __init__(self, font, list_of_players):
        self.font = font
        self.players = list_of_players

    @property
    def score_surface(self):
        
        score_text = ''
        for player in self.players:
            score_text += 'PLAYER' + str(player.player_number) + ': ' + str(player.score) + '  '
        score_text = score_text.strip(' ')

        score_surface = self.font.render(score_text, True, Score.FONT_COLOR)
        dest = ( WIN_WIDTH / 2 - score_surface.get_width() / 2, 
                PAD_Y / 2 - score_surface.get_height() / 2 + 2)
        return score_surface, dest

class Button(sprite.Sprite):

    def __init__(self, name, image):
        self.name = name
        self.image = image
        self.rect = Rect(0, 0, *self.image.get_size())
        self.mask = mask.from_surface(self.image)
        
class Moon(sprite.Sprite):

    def __init__(self, image):
        self.image = image
        self.org_location = [75, 50] # i calculated this on my on photoshop
        self.width, self.height = self.image.get_size()
        self.location = (self.org_location[0] - self.width / 2, self.org_location[1] - self.height / 2)
        self.rect = Rect(*self.location, *self.image.get_size())
        self.mask = mask.from_surface(self.image)

    def active_image(self, mouse_position):
        x, y = self.org_location
        dx = mouse_position[0] - x
        dy = y - mouse_position[1]
        try:
            rad_angle = atan(dy/dx)

            if dx < 0:
                rad_angle += 3.14

        except ZeroDivisionError:
            rad_angle = 0
        angle = 180 / 3.14 * rad_angle
        return transform.rotozoom(self.image, angle, 1) 

class EasterEgg(sprite.Sprite):
    
    DURATION = 5
    LINK = 'https://youtu.be/7vDCnAMnGCI'

    def __init__(self, image_easter_egg, image_button):
        self.image = image_easter_egg
        self.rect = Rect(0, 0, *self.image.get_size())
        self.mask = mask.from_surface(self.image)
        self.button = Button('CLICK HERE', image_button)
        self.initial_state = 0
        self.state = False

    def open_page(self):
        webbrowser.open(EasterEgg.LINK)

class mouse_point:

    def __init__(self, position):
        self.pos = position
        self.rect = Rect(*position, 1, 1)
        self.mask = mask.Mask((1, 1), True)

class click:
    def __init__(self, position):
        self.pos = position
        self.rect = Rect(*position, 1, 1)
        self.mask = mask.Mask((1, 1), True)

class Background:

    # constants that can be changed for developers
    TOTAL_BACKGROUND_NUMBER = 4
    IMAGE_NAME = [ 'Background'+ str(i) +'_Image' for i in range(1, TOTAL_BACKGROUND_NUMBER + 1) ]

    def __init__(self, name, images):
        self.name = name

        if self.name == 'Background1':
            self.image = images[0]
            self.snow_image = images[1]
            self.buttons = [ Button('START', images[2]) ]

        elif self.name == 'Background2':
            self.images = images[0:3]
            self.moon = Moon(images[3])
            self.easter_egg = EasterEgg(images[4], images[5])

        elif self.name == 'Background3':
            self.images = images[0:3]
            self.image = None
            self.buttons = [ Button('RESTART', images[3]) ]

        elif self.name == 'Background4':
            self.images = images[0:2]
            self.image = None
            self.buttons = [ Button('NEXT', images[2]), Button('SKIP', images[3]) ]

    @property
    def active_image(self):
        return self.images[ time.get_ticks() // (FPS * len(self.images) ** 2) % len(self.images) ]



# basic functions

def load_fonts():

    def load_font(font_name, font_size):
        try:
            file_name = path.join('.', 'game_files', 'fonts', font_name + '.otf')
            f = font.Font(file_name, font_size)
        except FileNotFoundError:
            file_name = path.join('.', 'game_files', 'fonts', font_name + '.ttf')
            f = font.Font(file_name, font_size)        
        return f

    return { 'BASIC': load_font(BASIC_FONT_NAME, BASIC_FONT_SIZE),
            Score: load_font(Score.FONT_NAME, Score.FONT_SIZE), 
            Present: load_font(Present.FONT_NAME, Present.FONT_SIZE), 
            Receiver: load_font(Receiver.FONT_NAME, Receiver.FONT_SIZE)}


def load_images():
    
    def load_image(image_name):
        file_name = path.join('.', 'game_files', 'images', image_name + '.png')
        img = image.load(file_name)
        img.convert()
        return img
    
    def try_loading(image_name):
        images = []
        i = 0
        while True:
            try:
                each_image_name = image_name + str(i)
                images.append(load_image(each_image_name))
                i += 1
            except FileNotFoundError:
                break
        return images
                

    return { Santa: [ try_loading(Santa.IMAGE_NAME[j]) for j in range(Santa.TOTAL_PLAYER_NUMBER) ],
            Present: try_loading(Present.IMAGE_NAME),
            Receiver: try_loading(Receiver.IMAGE_NAME),
            Background: [ try_loading(Background.IMAGE_NAME[j]) for j in range(Background.TOTAL_BACKGROUND_NUMBER) ]}

def music_player(state: str = 'ON'):
    '''
    music_player 
    
    state = 'ON' (default)
        loads and plays music

    state = 'OFF'
        unloads and stops music 
    '''
    
    if state == 'ON':
        file_name = path.join('.', 'game_files', 'musics', 'Christmas Village - Aaron Kenny.mp3')
        '''
        'Chirstmas Village - Aaron Kenny' music from https://youtu.be/Pv6nLSvrur4
        Music composed, performed and recorded by Aaron Kenny. 
        '''

        mixer.music.load(file_name) 
        mixer.music.play(loops = -1)

    elif state == 'OFF':

        mixer.music.stop()
        mixer.music.unload()

    else:
        raise error('The input for music_player must be \'ON\'or \'OFF\'')

def study_data_creator(STUDY_DATA, number):
    '''
    creates a new study_data dictionary with the size of the number inputted,
    while removing allocated data from STUDY_DATA    
    '''
    
    study_data = {}
    data_index = list(STUDY_DATA)
    shuffle(data_index)

    for _ in data_index[0:number]:
        study_data[_] = STUDY_DATA[_]
        del STUDY_DATA[_]

    return study_data

init()
display_surface = display.set_mode((WIN_WIDTH, WIN_HEIGHT))
display.set_caption('Educational Christmas Game')
clock = time.Clock()
clock.tick(FPS)
music_player('ON')

fonts = load_fonts()
images = load_images()

backgrounds = []
for i in range(Background.TOTAL_BACKGROUND_NUMBER):
    name = 'Background' + str(i + 1)
    backgrounds.append(Background(name, images[Background][i]))

game_over = False
play_time = 0
while not game_over:
    
    game_start = 0
    y = 0
    while game_start <= 2 and not game_over:
        
        snow_image = backgrounds[0].snow_image

        if play_time == 0:

            # start screen 

            if game_start == 0:
                background = backgrounds[0]
            
            # instructions

            else:
                background = backgrounds[3]
                background.image = background.images[ game_start - 1]

        # replay screen 
            
        else:
            background = backgrounds[2]

            # background differ by last winner

            if Santa.player_won:
                background.image = background.images[Santa.player_won - 1]
            else:
                background.image = background.images[2]
        

        # get events

        for e in event.get():
            if e.type == QUIT or (e.type == KEYDOWN and e.key == CONTROL['Command']['QUIT']):
                game_over = True

            elif e.type == MOUSEBUTTONDOWN:
                for button in background.buttons:
                    if sprite.collide_mask(button, click(e.pos)):
                        if button.name in ['SKIP', 'RESTART']:
                            game_start = 3
                        else:
                            game_start += 1

        # display

        display_surface.blit(background.image, (0, 0))
        for button in background.buttons:
            display_surface.blit(button.image, (0, 0))
        
        # snow
        if game_start == 0:
            display_surface.blit(snow_image, (0, y))
            display_surface.blit(snow_image, (0, y - WIN_HEIGHT))
            if y <= WIN_HEIGHT:
                y += 1
            else:
                y = 0

        display.flip()



    study_data = study_data_creator(STUDY_DATA, Present.TOTAL_PRESENT_NUMBER)
    study_data_indice = list(study_data)
    study_data_values = list(study_data.values())

    players = []
    for i in range(Santa.TOTAL_PLAYER_NUMBER):
        players.append(Santa(images[Santa][i]))

    receivers = []
    for _ in range(Receiver.TOTAL_RECEIVER_NUMBER):
        receivers.append(Receiver(fonts[Receiver], images[Receiver], study_data_indice.pop(0)))

    presents = []
    for _ in range(Present.TOTAL_PRESENT_NUMBER):
        presents.append(Present(fonts[Present], images[Present], study_data_values.pop(0)))

    scores = Score(fonts[Score], players)

    moon = backgrounds[1].moon
    easter_egg = backgrounds[1].easter_egg

    play_over = False
    while not play_over and not game_over:
        
        for e in event.get():
            if e.type == QUIT or (e.type == KEYDOWN and e.key == CONTROL['Command']['QUIT']):
                game_over = True

            elif e.type == KEYDOWN:

                if e.key in EVENT_TO_CONTROL['Command']:
                    pass
                
                else:
                    for i in range(Santa.TOTAL_PLAYER_NUMBER):
                        
                        player = players[i]
                        player_name = 'Player' + str(i + 1)
                        
                        if e.key in EVENT_TO_CONTROL[player_name]:
                            
                            command = EVENT_TO_CONTROL[player_name][e.key]
                            
                            if type(command) == Direction:
                                player.state += EVENT_TO_CONTROL[player_name][e.key]

                            elif command == 'HOLD':
                                player.hold_unhold(presents)

                            elif command == 'BOOST':
                                player.speed = Santa.BOOST_SPEED
                            
            elif e.type == KEYUP:

                for i in range(Santa.TOTAL_PLAYER_NUMBER):
                    
                    player = players[i]
                    player_name = 'Player' + str(i+1)
                    
                    if e.key in EVENT_TO_CONTROL[player_name]:

                        command = EVENT_TO_CONTROL[player_name][e.key]
                            
                        if type(command) == Direction:
                            player.state -= EVENT_TO_CONTROL[player_name][e.key]

                        elif command == 'BOOST':
                            player.speed = Santa.DEFAULT_SPEED
            
            elif e.type == MOUSEBUTTONDOWN:
                if easter_egg.state == True and sprite.collide_mask(easter_egg.button, click(e.pos)):
                    easter_egg.open_page()

        if sprite.collide_mask(moon, mouse_point(mouse.get_pos())):
            easter_egg.initial_state = EasterEgg.DURATION
        
        if sprite.collide_mask(moon, mouse_point(mouse.get_pos())) or sprite.collide_mask(easter_egg, mouse_point(mouse.get_pos())):
            easter_egg.state = True
        else:
            if easter_egg.initial_state > 0:
                easter_egg.initial_state -= 1 

        if easter_egg.initial_state == 0:
            easter_egg.state = False 
        
        # interaction

        interacting_objects = sprite.groupcollide(receivers, presents, False, False, sprite.collide_mask)
        for receiver, interacting_presents in interacting_objects.items():
            for present in interacting_presents:
                
                if present.held == None and present.rejected == None and present.tag != None:
                    
                    # correct answer
                    try:
                        if study_data[receiver.data] == present.data:
                            
                            # add score and remove present from present
                            player = present.tag
                            player.score += 1
                            present.tag = None
                            presents.remove(present)

                            try:
                                receiver.data = study_data_indice.pop(0)
                            
                            except IndexError:
                                receiver.data = ''
                                
                                if presents == []:
                                    play_over = True

                                    players.sort(key = lambda player: player.score, reverse = True)
                                    if players[0].score == players[1].score:
                                        Santa.player_won = None
                                    else:
                                        Santa.player_won = players[0].player_number

                                    Santa.player_number = 0
                                    Present.present_number = 0
                                    Present.created_presents = []
                                    Receiver.receiver_number = 0
                                    Receiver.created_receivers = []

                                    play_time += 1

                        # wrong answer
                        else:
                            
                            # reduce score and add present's rejected state
                            player = present.tag
                            player.score -= 1
                            present.tag = None
                            present.rejected = receiver
                    
                    except KeyError:
                        pass
                
        # display

        display_surface.blit(backgrounds[1].active_image, (0, 0))

        # display objects
        for player in players:            
            for _ in range(player.speed):
                player.update()

        for present in presents: 
            present.update()
            
        objects = receivers + players + presents
        objects.sort(key = lambda obj: obj.location[1] + obj.height)
        
        held_presents = []
        for object in objects:
            if type(object) == Present and object.held :
                held_presents.append(object)
            else:
                display_surface.blit(object.image, object.rect)
                if type(object) in [Present, Receiver]:
                    display_surface.blit(*object.font_surface)
        for present in held_presents:
            display_surface.blit(present.image, present.rect)
            display_surface.blit(*present.font_surface)

        display_surface.blit(moon.active_image(mouse.get_pos()), moon.location)
        if easter_egg.state == True:
            display_surface.blit(easter_egg.image, (0, 0))
            display_surface.blit(easter_egg.button.image, (0, 0))

        display_surface.blit(*scores.score_surface)
        display.flip()


