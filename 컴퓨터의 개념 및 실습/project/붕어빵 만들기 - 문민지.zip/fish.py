import pygame
import random
import os
from collections import deque
from collections import Counter
pygame.init()

class Frame:
    def __init__(self,game,key,x,y):
        self.game=game
        self.screen=game.screen
        self.key=key
        self.x=x  #x: right, y: top
        self.y=y
        self.state=deque(['open','close','rotate'])
        self.rotating=deque([0,1,2,3,4])
        self.frame=None
        self.fish=False
    open_image=pygame.image.load('image_var/판_틀.png')
    close_image=pygame.image.load('image_var/판_뚜껑.png')
    left_image=pygame.image.load('image_var/판_왼쪽.png')
    right_image=pygame.image.load('image_var/판_오른쪽.png')
    center_image=pygame.image.load('image_var/판_중앙.png')
    images=[right_image,center_image,left_image]

    def change_state(self,event):
        if event.type==pygame.KEYDOWN:
            if event.key==self.key:
                if self.fish:
                    if self.fish.cond==0 or self.fish.cond==1:
                        raise Exception
                self.rotating=deque([0,1,2,3,4])
                self.state.rotate(-1)
                self.rotating.rotate(-1)

    def mistake(self,event):
        if event.type==pygame.MOUSEBUTTONDOWN:
            if self.frame.collidepoint(event.pos):
                if self.state[0] !='open':
                    raise Exception

    def draw(self):
        if self.state[0]=='open':
            image=Frame.open_image
            self.rotating=deque([0,1,2,3,4])
        elif self.state[0]=='close':
            if self.rotating[0]==1:
                image=Frame.close_image
                self.rotating.rotate(-1)
            elif self.rotating[0]==0:
                image=Frame.close_image 
            else:
                i=self.rotating[0]
                image=Frame.images[i-2]
                self.rotating.rotate(-1)
        elif self.state[0]=='rotate':
            if self.rotating[0]==0:
                image=Frame.close_image
            elif self.rotating[0]==1:
                image=Frame.close_image
                self.rotating.rotate(-1)
            else:
                i=self.rotating[0]
                image=Frame.images[1-i]
                self.rotating.rotate(-1)
        self.frame=image.get_rect(right=self.x,top=self.y)
        self.screen.blit(image,self.frame)


class Fish():
    def __init__(self,game,frame):
        self.state='baking'
        self.cond=0
        self.time_front=0
        self.time_back=0
        self.time_temp=0
        self.time_temp_i=0
        self.cold=0
        self.game=game
        self.screen=game.screen
        self.frame=frame
        self.x=frame.x-17
        self.y=frame.y+22
        self.taste=None
        self.body=None
        self.choice=deque([0,1])
        self.good_time=game.good_time
    dough=pygame.image.load('image_var/반죽_일반.png')
    red_in=pygame.image.load('image_var/앙금_팥.png')
    cream_in=pygame.image.load('image_var/앙금_슈크림.png')
    mint_in=pygame.image.load('image_var/앙금_민트.png')
    red_burn=pygame.image.load('image_var/탄_팥.png')
    cream_burn=pygame.image.load('image_var/탄_슈크림.png')
    mint_burn=pygame.image.load('image_var/탄_민트.png')
    red_fish=pygame.image.load('image_var/붕어_팥.png')
    cream_fish=pygame.image.load('image_var/붕어_슈크림.png')
    mint_fish=pygame.image.load('image_var/붕어_민트.png')
    red_yet=pygame.image.load('image_var/덜익은_팥.png')
    cream_yet=pygame.image.load('image_var/덜익은_슈크림.png')
    mint_yet=pygame.image.load('image_var/덜익은_민트.png')
    line=pygame.image.load('image_var/선택.png')
    steam1=pygame.image.load('image_var/김1.png')
    steam2=pygame.image.load('image_var/김2.png')
    steam3=pygame.image.load('image_var/김3.png')
    taste_list=[red_in,cream_in,mint_in]
    burn_list=[red_burn,cream_burn,mint_burn]
    fish_list=[red_fish,cream_fish,mint_fish]
    yet_list=[red_yet,cream_yet,mint_yet]
    steam=deque([steam1,steam2,steam3])
    def event_response(self,event,pick):
        if event.type==pygame.MOUSEBUTTONDOWN:
            if self.body.collidepoint(event.pos):
                if event.button==pygame.BUTTON_RIGHT:    
                    if self.frame.state[0]!='open':
                        pass
                    elif self.cond==0:
                        self.taste=pick
                        self.cond+=1
                    else:
                        raise Exception
                if event.button==pygame.BUTTON_LEFT:          
                    if self.frame.state[0]!='open':
                        pass
                    elif self.cond==1:
                        self.cond+=1
                    elif self.cond==3:
                        self.choice.rotate(1)
                    else:
                        raise Exception
    def bake(self,event):
        if event.type==pygame.KEYDOWN:
            if event.key==self.frame.key:
                if self.cond==2:
                    self.cond=3
                    self.time_front_i=pygame.time.get_ticks()
                if self.cond==3:
                    if self.frame.state[0]=='close':
                        self.time_back_i=pygame.time.get_ticks()
                        self.time_front+=(self.time_back_i-self.time_front_i)/1000
                    elif self.frame.state[0]=='rotate':
                        self.time_back+=(pygame.time.get_ticks()-self.time_back_i)/1000
                    else:
                        self.time_front_i=pygame.time.get_ticks()
        if self.time_front>self.good_time+1 or self.time_back>self.good_time+1:
            self.state='burn'
        elif -1<=self.time_front-self.good_time<=1 and -1<=self.time_back-self.good_time<=1:
            self.state='well'
        else:
            self.state='yet'
    
    def draw(self):
        if self.cond==0:
            image=Fish.dough
            self.body=image.get_rect(right=self.x,top=self.y)
            self.screen.blit(image,self.body)
        elif self.cond==1:
            image=Fish.dough
            self.screen.blit(image,self.body)
            image=Fish.taste_list[self.taste]
            image_rect=image.get_rect(centerx=self.x-45,centery=self.y+70)
            self.screen.blit(image,image_rect)
        elif self.cond==2:
            if self.frame.state[0]=='open':
                image=Fish.dough
                self.body=image.get_rect(right=self.x,top=self.y)
                self.screen.blit(image,self.body)
        else:
            if self.frame.state[0]=='open':
                if self.state=='burn':
                    image=Fish.burn_list[self.taste]
                elif self.state=='well':
                    image=Fish.fish_list[self.taste]
                elif self.state=='yet':
                    image=Fish.yet_list[self.taste]
                self.body=image.get_rect(right=self.x,top=self.y)
                self.screen.blit(image,self.body)
                if self.choice[0]:
                    lined=self.line
                    lined_rect=lined.get_rect(right=self.x,top=self.y)
                    self.screen.blit(lined,lined_rect)
            elif self.frame.state[0]=='close':
                time_f=self.time_front+(pygame.time.get_ticks()-self.time_front_i)/1000
                if time_f>=self.good_time-1: 
                    current_steam=self.steam[0]
                    self.steam.rotate(-1)
                    current_steam_rect=current_steam.get_rect(right=self.x+20,top=self.y-70)
                    self.screen.blit(current_steam,current_steam_rect)
            else:
                time_b=self.time_back+(pygame.time.get_ticks()-self.time_back_i)/1000
                if time_b>=self.good_time-1:
                    current_steam=self.steam[0]
                    self.steam.rotate(-1)
                    current_steam_rect=current_steam.get_rect(right=self.x+20,top=self.y-70)
                    self.screen.blit(current_steam,current_steam_rect)

class Jar:
    red_jar=pygame.image.load('image_var/통_팥.png')
    cream_jar=pygame.image.load('image_var/통_슈크림.png')
    mint_jar=pygame.image.load('image_var/통_민트.png')
    choice_jar=pygame.image.load('image_var/통_선택.png')
    tastes_list=[red_jar,cream_jar,mint_jar]
    def __init__(self,x,y,game,tastes,pick):
        self.x=x
        self.y=y
        self.game=game
        self.tastes=tastes
        self.pick=pick
        self.red_jar_rect=self.red_jar.get_rect(right=self.x,top=self.y)
        self.cream_jar_rect=self.cream_jar.get_rect(right=self.x,top=self.y+120)
        self.mint_jar_rect=self.mint_jar.get_rect(right=self.x,top=self.y+240)
        self.tastes_rect_list=[self.red_jar_rect,self.cream_jar_rect,self.mint_jar_rect]
    
    def change_pick(self,event):
        for i in self.tastes:
            if event.type==pygame.MOUSEBUTTONDOWN:
                if self.tastes_rect_list[i].collidepoint(event.pos):
                    if event.button==pygame.BUTTON_LEFT:
                        raise Exception
                    elif event.button==pygame.BUTTON_RIGHT:
                        self.pick=i

    def draw(self):
        choice_jar_rect=Jar.choice_jar.get_rect(right=self.x,top=self.y+120*self.pick)
        for i in self.tastes:
            self.game.screen.blit(Jar.tastes_list[i],self.tastes_rect_list[i])
        self.game.screen.blit(Jar.choice_jar,choice_jar_rect)
        

class Container:
    def __init__(self,game,x,y,contain):
        self.game=game
        self.x=x
        self.y=y
        self.contain=contain
        self.saying=[]
    red_cont=pygame.image.load('image_var/말_팥.png')
    cream_cont=pygame.image.load('image_var/말_슈크림.png')
    mint_cont=pygame.image.load('image_var/말_민트.png')
    cont_list=[red_cont,cream_cont,mint_cont]

    def set_pos(self):
        order=0
        self.saying=[]
        for i in range(3):
            if i in self.contain:
                rect=Container.cont_list[i].get_rect(left=self.x-20,top=self.y+53*order)
                number=':%d' %(self.contain[i])
                font=pygame.font.Font(None,50)
                text=font.render(number,True,(0,0,0))
                text_rect=text.get_rect(left=self.x+20,top=self.y+10+53*order)
                self.saying.append([(self.cont_list[i],rect),(text,text_rect)])
                order+=1

    def draw(self):
        self.set_pos()
        for i in self.saying:
            self.game.screen.blit(*i[0])
            self.game.screen.blit(*i[1])

class Pack(Container):
    pack_image=pygame.image.load('image_var/봉투.png')
    pack_choice=pygame.image.load('image_var/봉투_선택.png') 
    def __init__(self,game,x, y):
        super().__init__(game,x,y,contain=None)
        self.fish_list=[]
        self.contain=Counter()
        self.pack_rect=Pack.pack_image.get_rect(right=self.x, top=self.y)
        self.state=0
        self.choice=deque([0,1])

    def add_fish(self,fish_list,slot_in):
        for fish in fish_list:
            self.contain[fish.taste]+=1
            if fish.state!='well':
                self.state+=1
            if fish.cold:
                self.state+=1
        for i in range(Case.length):
            try:
                if slot_in.slots[i].choice[0]==1:
                    del slot_in.slots[i]
            except:
                pass

    def choose(self,event,hand):
        if event.type==pygame.MOUSEBUTTONDOWN:
            if self.pack_rect.collidepoint(event.pos):
                if event.button==pygame.BUTTON_LEFT:
                    if len(hand)==0:
                        self.choice.rotate(1)
    def draw(self):
        self.game.screen.blit(self.pack_image,self.pack_rect)
        if self.choice[0]:
            self.game.screen.blit(self.pack_choice,self.pack_rect)
        super().draw()

class Person(Container):
    person_None=pygame.image.load('image_var/손님.png')
    person_Happy=pygame.image.load('image_var/손님_신남.png')
    person_Angry=pygame.image.load('image_var/손님_실망.png')
    balloon=pygame.image.load('image_var/말풍선.png')
    create=None
    wait=100
 
    def __init__(self,game,x,y,contain):
        super().__init__(game,x,y,contain)
        self.state=0
        self.t_came=pygame.time.get_ticks()
        self.x1=x+60
        self.y1=y+10
        self.money=0
        self.person_rect=None
        for i in range(3):
            self.money+=(self.contain[i]/self.game.price_list[i][0])*self.game.price_list[i][1]
        self.t=game.t
        self.dw=Person.wait/self.t
        self.happy_point=game.happy_point
    
    def waiting(self):
        if self.state==0:
            t_wait=(pygame.time.get_ticks()-self.t_came)/1000
            if t_wait>self.t:
                self.state=-2
                self.t_finish=pygame.time.get_ticks()
                self.game.fame-=self.game.dfame*3

    def draw(self):
        if self.state==0:
            self.person_rect=Person.person_None.get_rect(right=self.x1,top=self.y1)
            self.game.screen.blit(Person.person_None,self.person_rect)
            balloon_rect=Person.balloon.get_rect(left=self.x1-110,top=self.y1-20)
            self.game.screen.blit(Person.balloon,balloon_rect)
            super().draw()
            temp=self.dw*(pygame.time.get_ticks()-self.t_came)/1000
            pygame.draw.rect(self.game.screen,(255,0,0),(self.x1-260,self.y1+40+temp,10,Person.wait-temp))
        elif self.state==1:
            if (pygame.time.get_ticks()-self.t_finish)/1000<=1:
                rect=Person.person_Happy.get_rect(right=self.x1,top=self.y1)
                self.game.screen.blit(Person.person_Happy,rect)
            else:
                self.state=2
        else:
            if (pygame.time.get_ticks()-self.t_finish)/1000<=1:
                rect=Person.person_Angry.get_rect(right=self.x1,top=self.y1)
                self.game.screen.blit(Person.person_Angry,rect)
            else:
                self.state=2


    def give(self,pack):
        if pack.choice[0]:
            self.t_finish=pygame.time.get_ticks()
            if pack.contain==self.contain:
                if pack.state==0:
                    self.state=1
                    self.game.money+=self.money
                    self.game.fame+=self.game.dfame*self.happy_point
                else:
                    self.state=-1
                    self.game.money+=self.money
                    self.game.fame-=self.game.dfame*pack.state
            else:
                self.state=-2
                self.game.fame-=self.game.dfame*3
            pack.contain=Counter({})
            pack.state=0
            pack.choice.rotate(1)

class Slot:
    def __init__(self,game):
        self.game=game
        self.slots={}
        self.length=0

    def put(self,one):                 
        for i in range(self.length):
            if not(i in self.slots):                   
                self.slots[i]=one
                break
        else:
            raise Exception

class Case(Slot):
    def __init__(self,game):
        super().__init__(game)
        self.x=220
        self.y=265
        self.length=8
        self.time_case=game.time_case

    length=8
    def put(self,fish):
        for i in range(self.length):
            try:
                if self.slots[i]==fish:
                    fish.time_temp+=(pygame.time.get_ticks()-fish.time_temp_i)/1000
                    del self.slots[i]
            except:
                pass
        super().put(fish)
        fish.time_temp_i=pygame.time.get_ticks()
        fish.choice.rotate(1)

    def choose(self,event,pack):
        if not pack.choice[0]:
            if event.type==pygame.MOUSEBUTTONDOWN:
                for i in self.slots.keys():
                        f=self.slots[i]
                        if f.f_rect.collidepoint(event.pos) and event.button==pygame.BUTTON_LEFT:
                            f.choice.rotate(1)
    
    def add2hand(self,hand):
        for i in self.slots.keys():
            if self.slots[i].choice[0]:
                hand.append(self.slots[i])

    def draw(self):
        for i in range(self.length):
            try:
                f=self.slots[i]
                if f.state=='burn':
                    image=Fish.burn_list[f.taste]
                elif f.state=='well':
                    image=Fish.fish_list[f.taste]
                elif f.state=='yet':
                    image=Fish.yet_list[f.taste]
                image=pygame.transform.scale(image,(53,75))
                f.f_rect=image.get_rect(left=self.x+i*75,top=self.y)
                self.game.screen.blit(image,f.f_rect)
                dx=(pygame.time.get_ticks()-f.time_temp_i)/1000
                if f.time_temp+dx<=self.time_case:
                    temp=75*(f.time_temp+dx)/self.time_case
                    pygame.draw.rect(self.game.screen,(0,50,255),(self.x+i*75-5,self.y+temp,5,75-temp))
                else:
                    f.cold=1
                if f.choice[0]:
                    line=pygame.transform.scale(Fish.line,(53,75))
                    line_rect=line.get_rect(left=self.x+i*75,top=self.y)
                    self.game.screen.blit(line,line_rect)
            except:
                pass
                
class Customer(Slot):
    def __init__(self,game):
        super().__init__(game)
        self.length=3

    def put(self,person):
        if Person.create==None or (pygame.time.get_ticks()-Person.create)/1000>self.game.time_person:
            super().put(person)
            Person.create=pygame.time.get_ticks()

    def set_people_pos(self):    
        for i in range(3):                         
            if i in self.slots:
                self.slots[i].x=260+i*250
                self.slots[i].x1=320+i*250
                self.slots[i].waiting()
                self.slots[i].draw()
                if self.slots[i].state==2:
                    del self.slots[i]

class Game:   
    width=1040
    height=780
    tick=30
    screen=pygame.display.set_mode((width,height))
    pygame.display.set_caption('붕어빵 만들기')
    clock=pygame.time.Clock()
    background=pygame.image.load('image_var/배경.png')
    background=pygame.transform.scale(background,(width,height))
    plate=pygame.image.load('image_var/판.png')
    plate=pygame.transform.scale(plate,(width,height))    
    trashcan=pygame.image.load('image_var/쓰레기통.png')
    trashcan_rect=trashcan.get_rect(left=5,top=200)
    keys=[[pygame.K_t,pygame.K_r,pygame.K_e,pygame.K_w,pygame.K_q],[pygame.K_g,pygame.K_f,pygame.K_d,pygame.K_s,pygame.K_a]]
    quit_game=False
    time_game_over=0
    time_ending=0
    redbean=0
    cream=1
    mint=2
    def __init__(self):
        self.money=1000
        self.fame=50
        self.price_list=[(3,1000),(2,1000),(1,1500)]
        self.dfame=5
        self.inside=Jar(170,400,self,[Game.redbean],Game.redbean)
        self.num_order=1
        self.game_over=False
        self.route=0
        self.good_time=5
        self.t=40
        self.happy_point=2
        self.time_case=100
        self.time_person=20
    def menu(self):
        x=340
        y=450
        #images
        bg_menu=pygame.image.load('image_var/bg_menu.png')
        button_start=pygame.image.load('image_var/button_start.png')
        button_start_rect=button_start.get_rect(left=x,top=y)
        move=False

        while (not move) and (not self.quit_game):
            self.screen.blit(bg_menu,(0,0))
            self.screen.blit(button_start,button_start_rect)
            self.clock.tick(30)
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.quit_game=True
                elif event.type==pygame.MOUSEBUTTONDOWN:
                    if button_start_rect.collidepoint(event.pos):
                        if event.button==pygame.BUTTON_LEFT:
                            move=True
            pygame.display.update()
            

    def tutorial(self):
        if not self.quit_game:
            images=[]
            for i in range(1,21):
                images.append(pygame.image.load('image_var/%d.png'%i ))
            button_yes=pygame.image.load('image_var/button_yes.png')
            yes_rect=button_yes.get_rect(left=150,bottom=self.height-60)
            button_no=pygame.image.load('image_var/button_no.png')
            no_rect=button_no.get_rect(left=500,bottom=self.height-60)
            image_out=pygame.image.load('image_var/5-1.png')
            for i in range(20):
                go2next=False
                answer=True
                while not go2next:
                    self.screen.blit(images[i],(0,0))
                    if i==4:
                        self.screen.blit(button_yes,yes_rect)
                        self.screen.blit(button_no,no_rect)
                    pygame.display.update()
                    for event in pygame.event.get():
                        if event.type==pygame.QUIT:
                            self.quit_game=True
                            go2next=True
                        elif event.type==pygame.MOUSEBUTTONDOWN:
                            if event.button==pygame.BUTTON_LEFT:
                                if i==4:
                                    if yes_rect.collidepoint(event.pos):
                                        go2next=True
                                    elif no_rect.collidepoint(event.pos):
                                        answer=False
                                        go2next=True
                                else:
                                    go2next=True
                    self.clock.tick(self.tick)
                if not answer:
                    start=False
                    while not start:
                        self.screen.blit(image_out,(0,0))
                        pygame.display.update()
                        for event in pygame.event.get():
                            if event.type==pygame.MOUSEBUTTONDOWN and event.button==pygame.BUTTON_LEFT:
                                start=True
                    break
                if self.quit_game:
                    break
    

    def path1(self):
        path1_1=pygame.image.load('image_var/path1_1.png')
        path1_2=pygame.image.load('image_var/path1_2.png')
        time_start=pygame.time.get_ticks() 
        while True:
            self.clock.tick(self.tick)
            self.screen.blit(path1_1,(0,0))
            pygame.display.update()
            a=False
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.quit_game=True
                    a=True
                if pygame.time.get_ticks()-time_start>1500:    
                    if event.type==pygame.MOUSEBUTTONDOWN and event.button==pygame.BUTTON_LEFT:
                        a=True
            if a:
                break
        while True:
            self.clock.tick(self.tick)
            self.screen.blit(path1_2,(0,0))
            pygame.display.update()
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.quit_game=True
                    break
                if event.type==pygame.MOUSEBUTTONDOWN and event.button==pygame.BUTTON_LEFT:
                    if event.pos[0]<self.width/2-100:
                        self.route=1
                    elif event.pos[0]>self.width/2+100:
                        self.route=2
            if self.quit_game:
                break
            if self.route==1:
                self.good_time=4
                self.time_person=17
                break
            elif self.route==2:
                self.inside.tastes=[Game.redbean,Game.cream]
                self.time_person=17
                break

    def path2(self):
        path2=pygame.image.load('image_var/path2.png')
        path2_1=pygame.image.load('image_var/path2_1.png')  
        path2_2=pygame.image.load('image_var/path2_2.png')
        time_start=pygame.time.get_ticks() 
        while True:
            self.clock.tick(self.tick)
            self.screen.blit(path2,(0,0))
            pygame.display.update()
            a=False
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.quit_game=True
                    a=True
                if pygame.time.get_ticks()-time_start>1500:
                    if event.type==pygame.MOUSEBUTTONDOWN and event.button==pygame.BUTTON_LEFT:
                        a=True
            if a:
                break
        while True:
            self.clock.tick(self.tick)
            if self.route==1:
                self.screen.blit(path2_1,(0,0))
            elif self.route==2:
                self.screen.blit(path2_2,(0,0))
            pygame.display.update()
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.quit_game=True
                    break
                if event.type==pygame.MOUSEBUTTONDOWN and event.button==pygame.BUTTON_LEFT:
                    if event.pos[0]<self.width/2-100:
                        if self.route==1:
                            self.route=3
                        elif self.route==2:
                            self.route=5
                    elif event.pos[0]>self.width/2+100:
                        if self.route==1:
                            self.route=4
                        elif self.route==2:
                            self.route=6
            if self.quit_game:
                break
            if self.route==3:
                self.good_time=2
                self.price_list[0]=(5,1000)
                self.t=60
                self.dfame=2
                self.happy_point=5/2*self.happy_point
                break
            
            elif self.route==4:
                self.price_list[0]=(2,1000)
                self.t=30
                self.dfame=8
                self.happy_point=5/8*self.happy_point
                break

            elif self.route==5:
                self.t=60
                self.dfame=2
                self.happy_point=5/2*self.happy_point
                self.time_case=130
                break

            elif self.route==6:
                self.inside.tastes=[Game.redbean,Game.cream,Game.mint]
                self.time_person=15
                self.price_list[0]=(2,1000)
                self.price_list[1]=(3,2000)
                self.t=35
                self.dfame=8
                break
        
    def write(self,text,size,x,y):
        font=pygame.font.Font(None,size)
        tex=font.render(text,True,(0,0,0))
        text_pos=tex.get_rect(right=x,top=y)
        self.screen.blit(tex,text_pos)

    def play(self):
        hand=[]
        frames=[]
        fishes=[]
        pack=Pack(game=self,x=self.width-70,y=200)
        People=Customer(self)
        fish_case=Case(self)
        going_on=True

          
        for j in range(2):                     #틀 형성
            for i in range(5):   
                 frames.append(Frame(self,self.keys[j][i],850-i*133,350+j*210))
        
        end_game=False                         #end_game: play 끝내고 다음으로
        while not self.quit_game and not end_game:

            ## event에 반응(player와 상호작용)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:  #게임 창 닫는 조건
                    self.quit_game=True
                if not self.game_over and self.money<100000:   
                    temp=fishes[:]             # 임시 fishes              
                    delList=[]                 # 붕어빵 제거 목록

                    ##마우스 클릭 관련
                    if event.type==pygame.MOUSEBUTTONDOWN: 

                        if event.button==pygame.BUTTON_LEFT:
                            if self.trashcan_rect.collidepoint(event.pos): #붕어빵 버리기
                                for fish in hand:
                                    if fish in fishes:
                                        fish.frame.fish=False
                                        fishes.remove(fish)
                                    else:
                                        for i in range(fish_case.length):
                                            try:
                                                if fish_case.slots[i]==fish:
                                                    del fish_case.slots[i]
                                            except:
                                                pass

                            elif pack.pack_rect.collidepoint(event.pos):   #봉투에 넣기
                                if len(hand)!=0:
                                    packing=[]
                                    for fish in hand:
                                        packing.append(fish)
                                        if fish.frame:
                                            fish.frame.fish=False
                                        try:
                                            fishes.remove(fish)
                                        except:
                                            pass
                                    pack.add_fish(packing,fish_case)

                            for man in People.slots.values():
                                if man.person_rect.collidepoint(event.pos): #손님에게 주기
                                    if pack.choice[0]:
                                        man.give(pack)

                        fish_case.choose(event,pack)                        #보관된 붕어빵 선택 

                        try:
                            self.inside.change_pick(event)                  #소 선택
                        except:
                            self.money-=50

                        for fish in temp:
                            try:                                            #반죽 붓기
                                fish.event_response(event,self.inside.pick)
                            except:
                                self.money-=50
                                delList.append(fish)
                                fishes.remove(fish)
                        
                        for elem in frames:                                 
                            try:                                     
                                if event.button ==pygame.BUTTON_LEFT:        #새 붕어빵 생성
                                    if elem.frame.collidepoint(event.pos) and not elem.fish:
                                        if elem.state[0]=='open':
                                            newfish=Fish(self,elem)
                                            fishes.append(newfish)
                                            elem.fish=newfish
                                elem.mistake(event)                          #실수 확인
                            except:
                                self.money-=50
                                if elem.fish and elem.fish.cond!=3:
                                    delList.append(elem.fish)
                                    fishes.remove(elem.fish)
                        
                        pack.choose(event,hand)


                    ## 키보드 관련
                    if event.type==pygame.KEYDOWN:               
                        for fish in temp:                          #붕어빵 굽기
                            fish.bake(event)

                        for elem in frames:
                            try:
                                elem.change_state(event)             #틀 상태 바꾸기
                            except:
                                self.money-=50
                                delList.append(fish)
                                fishes.remove(fish)                                

                        if event.key==pygame.K_SPACE:             #붕어빵 보관
                            for fish in hand:
                                try:
                                    fish_case.put(fish)
                                    fish.frame.fish=False
                                    fish.frame=False
                                    fishes.remove(fish)
                                except:
                                    pass 


                    ##붕어빵 제거 목록의 붕어빵들 틀과 연결 해제     
                    for fish in delList:                                
                        fish.frame.fish=False
                    

            ## player가 관여 못함
            if not self.game_over and self.money<100000:                #손님 생성
                if going_on:
                    num=random.randint(1,self.num_order)
                    l=len(self.inside.tastes)
                    order=[]
                    for i in range(l):
                        if i!=l-1:
                            a=random.randint(0,num)
                            order.append(a)
                            num=num-a
                        else:
                            order.append(num)
                    order_f={}
                    for i in range(l):
                        if order[i]:
                            order_f[i]=order[i]*self.price_list[i][0]
                    contain=Counter(order_f)
                    person=Person(self,260,50,contain)
                    try:
                        People.put(person)

                    except:
                        pass
                
                
                ## 그리기
                
                self.screen.blit(self.background,(0,0))
                People.set_people_pos()                                   #손님 배치
                self.screen.blit(self.plate,(0,0))
                self.screen.blit(self.trashcan,self.trashcan_rect)

                hand.clear()
                
                for elem in frames:
                    elem.draw()
                for f in fishes:
                    if f.choice[0]:
                        hand.append(f)
                    f.draw()    
                fish_case.add2hand(hand)

                self.inside.draw()
                pack.draw()

                if self.fame>100:
                    self.fame=100
                fish_case.draw()    
                current_money='%d' %(self.money)
                current_fame='%d'%(self.fame)
                self.write(current_money, 40, self.width-30,33)
                self.write(current_fame, 40, self.width-30, 85)

                ##game over condition
                if self.money<0 or self.fame<0:
                    self.game_over=True
                    self.time_game_over=pygame.time.get_ticks()
                
                ##다음 루트 가는 조건
                if self.route==0:
                    if 7000<self.money<20000:
                        self.num_order=2
                    elif 20000<=self.money:
                        going_on=False
                        if len(People.slots)==0:
                            end_game=True

                if self.route==1 or self.route==2:
                    if self.money>50000:
                        going_on=False
                        if len(People.slots)==0:
                            end_game=True 

            ##ending
            elif self.money>100000:
                if self.time_ending==0:
                    self.time_ending=pygame.time.get_ticks()
                n=self.route
                ending_image=pygame.image.load('image_var/ending_%d.png'%n)
                self.screen.blit(ending_image,(0,0))
                if pygame.time.get_ticks()-self.time_ending>1500:
                    for event in pygame.event.get():
                        if event.type==pygame.MOUSEBUTTONDOWN:
                            if event.button==pygame.BUTTON_LEFT:
                                end_game=True             
            
            ##game over
            else:
                over_image=pygame.image.load('image_var/game_over.png')
                self.screen.blit(over_image,(0,0))
                if pygame.time.get_ticks()-self.time_game_over>1500:
                    for event in pygame.event.get():
                        if event.type==pygame.MOUSEBUTTONDOWN:
                            if event.button==pygame.BUTTON_LEFT:
                                end_game=True

            pygame.display.update()
            self.clock.tick(self.tick)

if __name__ == "__main__":
    while True:
        g=Game()
        g.menu()
        g.tutorial()
        g.play()
        if not g.game_over and not g.quit_game:
            g.path1()
            g.play()
            if not g.game_over and not g.quit_game:
                g.path2()
                g.play()
        
        if g.quit_game:
            break


            
            