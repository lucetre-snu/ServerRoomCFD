import pygame
import math
import random
import time

def dist(a,b):
    distance=math.sqrt((a.x-b.x)**2+(a.y-b.y)**2)
    return distance

class Player:
    def __init__(self,x,y,pixel,game):
        self.x=x
        self.y=y
        self.pixel=pixel
        self.game=game
        self.power=5
        self.attack_range=self.pixel*5
        self.direction='down'
        self.imgs=[pygame.image.load('assets/p_down.png'),pygame.image.load('assets/p_up.png'),
        pygame.image.load('assets/p_right.png'),pygame.image.load('assets/p_left.png')]
        self.image=self.imgs[0]
        self.surface=pygame.Surface((self.pixel,self.pixel))
        self.surface.set_alpha(255)
        self.surface.set_colorkey((0,0,0))
        self.inventory=[]
        self.p_inventory=[]
        self.hp=100
        self.can_move=True
        self.action=0
        self.ammo=15
    #always
    def show(self,screen):
        self.surface=pygame.Surface((self.pixel+10,self.pixel+5))
        self.surface.set_colorkey((0,0,0))
        self.surface.blit(self.image,(0,0))
        screen.blit(self.surface,(self.x-10,self.y-10))

    #keypressed
    def interact(self,other,k):
        if other.dist==0 and k==pygame.K_e:
            if isinstance(other,Item):
                if other.name=='medkit':
                    self.inventory.append('medkit')
                    other.active=False
                else:
                    self.ammo+=10
                    other.active=False
            elif isinstance(other,Exit):
                self.game.result='Success'

    def attack(self,k,bullet_lst,mob_lst):
        if k==pygame.K_q:
            if self.ammo!=0:
                bullet_lst.append(Bullet(self.x,self.y,self.pixel,self.game,self.direction,self.power))
                self.ammo-=1
                if self.direction=='up':
                    for i in mob_lst:
                        if i.x==self.x and i.y<self.y:
                            i.hp-=self.power
                elif self.direction=='down':
                    for i in mob_lst:
                        if i.x==self.x and i.y>self.y:
                            i.hp-=self.power
                elif self.direction=='left':
                    for i in mob_lst:
                        if i.y==self.y and i.x<self.x:
                            i.hp-=self.power
                elif self.direction=='right':
                    for i in mob_lst:
                        if i.y==self.y and i.x>self.x:
                            i.hp-=self.power

    def change_direction(self,k):
        front=''
        self.can_move=True
        if k==pygame.K_w:
            self.direction='up'
            self.image=self.imgs[1]
            front=[self.x,self.y-self.pixel]
        elif k==pygame.K_a:
            self.direction='left'
            self.image=self.imgs[3]
            front=[self.x-self.pixel,self.y]
        elif k==pygame.K_s:
            self.direction='down'
            self.image=self.imgs[0]
            front=[self.x,self.y+self.pixel]
        elif k==pygame.K_d:
            self.direction='right'
            self.image=self.imgs[2]
            front=[self.x+self.pixel,self.y]
        for i in self.game.mob_lst:
            if [i.x,i.y]==front:
                self.can_move=False
    
    def heal(self,k):
        if k==pygame.K_h:
            if self.inventory.count('medkit')>0:

                self.inventory.remove('medkit')
                if self.hp>=80:
                    self.hp=100
                else:
                    self.hp+=20

class Bullet:
    def __init__(self,x,y,pixel,game,direction,power):
        self.x=x
        self.y=y
        self.centerX=x
        self.centerY=y
        self.width=3
        self.height=7
        self.pixel=pixel
        self.game=game
        self.direction=direction
        self.power=power
        self.speed=25
        self.active=True
        self.c=(255,0,0)
        self.range=(self.game.height/self.pixel-1)/2*self.pixel #125
    def fire(self,screen):
        if self.direction=='up':
            if self.y>=self.centerY-self.range:
                pygame.draw.rect(screen,self.c,[self.x+self.pixel/2-self.width/2,self.y,self.width,self.height])
                self.y-=self.speed
            else:
                self.active=False
        elif self.direction=='down':
            if self.y<=self.centerY+self.range:
                pygame.draw.rect(screen,self.c,[self.x+self.pixel/2-self.width/2,self.y+self.pixel-self.height,self.width,self.height])
                self.y+=self.speed
            else:
                self.active=False
        elif self.direction=='left':
            if self.x>=self.centerX-self.range:
                pygame.draw.rect(screen,self.c,[self.x,self.y+self.pixel/2-self.width/2,self.height,self.width])
                self.x-=self.speed
            else:
                self.active=False
        elif self.direction=='right':
            if self.x<=self.centerX+self.range:
                pygame.draw.rect(screen,self.c,[self.x+self.pixel-self.height,self.y+self.pixel/2-self.width/2,self.height,self.width])
                self.x+=self.speed
            else:
                self.active=False


class Chunk:
    def __init__(self,x,y,pixel,game):
        self.x=x
        self.y=y
        self.pixel=pixel
        self.game=game
        self.item_spawn=True
        self.mob_spawn=True
        self.sur=random.randint(0,1000)
        self.image=''
        if self.sur<995:
            self.image=pygame.image.load("assets/chunk.png").convert_alpha()
        else:
            self.image=random.choice([pygame.image.load("assets/chunk5.png").convert_alpha(),
                                    pygame.image.load("assets/chunk6.png").convert_alpha()])
        self.surface=pygame.Surface((self.pixel,self.pixel))
        self.alpha=0
        self.surface.set_colorkey((0,0,0))
        self.surface.set_alpha(self.alpha)
        if len(self.game.element_lst)>0:
            for i in self.game.element_lst:
                if dist(self,i)<100:
                    self.item_spawn=False
        if len(self.game.mob_lst)>0:
            for i in self.game.mob_lst:
                if dist(self,i)<400:
                    self.mob_spawn=False
        self.dist=999
        self.item_poten=random.randint(0,1000)
        self.mob_poten=random.randint(0,1000)
        if len(self.game.exit_lst)==1:
            self.mob_poten=random.randint(900,1100)
        if self.item_spawn and self.item_poten>self.game.item_spawn_rate and dist(self,game.p)>100:
            self.game.element_lst.append(Item(self.x,self.y,self.pixel,self.game))
        else:
            self.item_spawn=False
        if self.mob_spawn and self.mob_poten>(self.game.mob_spawn_rate-(self.game.p.action)/10) and dist(self,game.p)>300:
            self.game.mob_lst.append(Mob(self.x,self.y,self.pixel,self.game))
        if not self.item_spawn and self.game.kill_score>=self.game.goal and len(self.game.exit_lst)==0 and random.randint(0,1000)>995:
            self.game.exit_lst.append(Exit(self.x,self.y,self.pixel,self.game))
    def change_image(self):
        self.image=pygame.image.load("assets/groundblood.png")

    #always
    def show(self,screen):
        self.alpha=self.game.sight-self.dist*2
        if self.alpha<0:
            self.alpha=0
        elif self.alpha>255:
            self.alpha=255
        self.surface.set_alpha(self.alpha)
        self.surface.blit(self.image,(0,0))
        screen.blit(self.surface,(self.x,self.y))
    
class Item:
    def __init__(self,x,y,pixel,game):
        self.x=x
        self.y=y
        self.pixel=pixel
        self.game=game
        self.active=True
        self.surface=pygame.Surface((self.pixel,self.pixel))
        self.name=random.choice(['medkit','ammo'])
        if self.name=='medkit':
            self.image=pygame.image.load("assets/medikit.png").convert_alpha()
            
        else:
            self.image=pygame.image.load('assets/ammo.png').convert_alpha()
        self.dist=999
        self.alpha=0
        
        self.surface.set_colorkey((255,255,255))
        self.surface.set_alpha(self.alpha)
    def show(self,screen):
        self.alpha=self.game.sight-self.dist*2
        if self.alpha<0:
            self.alpha=0
        elif self.alpha>255:
            self.alpha=255
        self.surface.set_alpha(self.alpha)
        self.surface.blit(self.image,(0,0))
        screen.blit(self.surface,(self.x,self.y))
        # pygame.draw.rect(screen,(255,255,0),[self.x,self.y,self.pixel/5,self.pixel/5])

class Mob:
    def __init__(self,x,y,pixel,game):
        self.x=x
        self.y=y
        self.pixel=pixel
        self.game=game
        self.fullhp=game.mob_hp
        self.hp=self.fullhp
        self.active=True
        self.power=self.game.mob_attack
        self.dist=999
        self.imgs=[pygame.image.load('assets/mob_down.png'),pygame.image.load('assets/mob_up.png'),
        pygame.image.load('assets/mob_right.png'),pygame.image.load('assets/mob_left.png')]
        self.image=self.imgs[0]
        self.alpha=0
        self.ready=False
        self.melee=False
        self.surface=pygame.Surface((self.pixel,self.pixel))
        self.surface.set_colorkey((0,0,0))
        self.surface.set_alpha(self.alpha)
        self.surface2=pygame.Surface((self.pixel,self.pixel))
        self.surface2.set_alpha(120)
    #always
    def melee_check(self,player):
        if dist(self,player)==self.pixel:
            self.melee=True
        else:
            self.melee=False

    def show(self,screen):
        self.melee_check(self.game.p)
        self.alpha=self.game.sight-self.dist*2
        if self.alpha<0:
            self.alpha=0
        elif self.alpha>255:
            self.alpha=255
        if self.melee:
            self.surface2.set_alpha(120)
            pygame.draw.rect(self.surface2,(255,0,0),[0,0,self.pixel,self.pixel])
            screen.blit(self.surface2,(self.x,self.y))
        else:
            self.surface2.set_alpha(0)
        self.surface=pygame.Surface((self.pixel+10,self.pixel+5))
        self.surface.set_colorkey((0,0,0))
        self.surface.set_alpha(self.alpha)
        self.surface.blit(self.image,(0,0))
        screen.blit(self.surface,(self.x-10,self.y-10))
        if self.hp<self.fullhp:
            pygame.draw.rect(screen,(235, 64, 52),
            [self.x+self.pixel*1/5,self.y-self.pixel*1/5,
            self.pixel*3/5,self.pixel/5])
            pygame.draw.rect(screen,(0,255,0),
            [self.x+self.pixel*1/5,self.y-self.pixel*1/5,
            self.hp/self.fullhp*self.pixel*3/5,self.pixel/5])
    
    #keypressed
    def attack(self,player):
        a=self.x-player.x
        b=self.y-player.y
        if (a==0 and abs(b)==self.pixel) or (b==0 and abs(a)==self.pixel): #근접
            self.ready=True
        else:
            self.ready=False
        if self.ready:
            player.hp-=self.power
            if player.x-self.x==self.pixel:
                self.image=self.imgs[2]
            elif player.x-self.x==-self.pixel:
                self.image=self.imgs[3]
            elif player.y-self.y==self.pixel:
                self.image=self.imgs[0]
            else:
                self.image=self.imgs[1]

    def move(self,player):
        past=[self.x,self.y]
        a=self.x-player.x
        b=self.y-player.y
        c=dist(self,player)
        if c<=25: #근접
            self.ready=True
        else:
            self.ready=False
            #이동 방향 체크
            possible=[]
            if a==0 and b!=0:
                possible=[[self.x,self.y-b/abs(b)*self.pixel]] #x가 같고 y로 이동
            elif a!=0 and b==0:
                possible=[[self.x-a/abs(a)*self.pixel,self.y]] #y가 같고 x로 이동
            elif a!=0 and b!=0:
                possible=[[self.x-a/abs(a)*self.pixel,self.y],[self.x,self.y-b/abs(b)*self.pixel]] #x,y 둘 중 하나 이동
            #이동 가능 체크
            result=[]
            for x in range(len(possible)):
                result.append(True)
            for j in range(len(possible)):
                for i in self.game.mob_lst: #다른 몹들과 중복 방지
                    others=[i.x,i.y]
                    if others==possible[j] and others!=[self.x,self.y]:
                        result[j]=False
            #이동
            if len(result)==1 and result[0]: #한 방향인데 가능
                self.x=possible[0][0]
                self.y=possible[0][1]
            elif len(result)==2:
                if result[0] and (not result[1]): #두 방향인데 한 방향만 가능1
                    self.x=possible[0][0]
                    self.y=possible[0][1]
                elif (not result[0]) and result[1]: #두 방향인데 한 방향만 가능2
                    self.x=possible[1][0]
                    self.y=possible[1][1]
                elif result[0] and result[1]: #둘 다 가능(랜덤)
                    r=random.randint(0,1)
                    self.x=possible[r][0]
                    self.y=possible[r][1]
            elif len(result)==1 and (not result[0]):
                if possible[0][0]==self.x:
                    possible=[[self.x-self.pixel,self.y],[self.x+self.pixel,self.y]]
                elif possible[0][1]==self.y:
                    possible=[[self.x,self.y+self.pixel],[self.x,self.y-self.pixel]]
                result2=[True,True]
                for i in self.game.mob_lst:
                    for j in range(2):
                        others2=[i.x,i.y]
                        if others2==possible[j] and others2!=[self.x,self.y]:
                            result2[j]=False
                if result2[0] and result2[1]:
                    r2=random.randint(0,1)
                    self.x=possible[r2][0]
                    self.y=possible[r2][1]
                elif result2[0] and not result2[1]:
                    self.x=possible[0][0]
                    self.y=possible[0][1]
                elif (not result2[0]) and result2[1]:
                    self.x=possible[1][0]
                    self.y=possible[1][1]
        if past[0]!=self.x:
            if past[0]-self.x<0:
                self.image=self.imgs[2]
            else:
                self.image=self.imgs[3]
        elif past[1]!=self.y:
            if past[1]-self.y<0:
                self.image=self.imgs[0]
            else:
                self.image=self.imgs[1]

class Exit:
    def __init__(self,x,y,pixel,game):
        self.x=x
        self.y=y
        self.pixel=pixel
        self.game=game
        self.image=pygame.image.load('assets/exit.jpg')
        self.dist=999
    def show(self,screen):
        screen.blit(self.image,(self.x,self.y))

class Control:
    def __init__(self,game):
        self.timer=0
        self.delay=2
        self.game=game
    
    def turn_check(self):
        self.game.mob_turn=False
        if self.timer==self.delay//2:
            self.game.mob_turn=True
        if self.timer==self.delay:
            self.game.player_turn=True
            self.timer=0
            
        if not self.game.player_turn:
            self.game.player_turn=False
            self.timer+=1

    def getKey(self,event,game):
        k_lst=[pygame.K_w,pygame.K_a,pygame.K_s,pygame.K_d,pygame.K_e,pygame.K_h,pygame.K_q]
        if event.type==pygame.QUIT:
            game.run=False
            game.gameRun=False
        if self.game.player_turn and event.type==pygame.KEYUP and event.key in k_lst:
            self.game.p.action+=1
            self.game.player_turn=False
            game.k=event.key

#always
class Status:
    def __init__(self,game,font):
        self.game=game
        self.image=pygame.image.load('assets/status.jpg')
        self.medkit=0
        self.ammo=0
        self.hp=100
        self.action=0
        self.score=0
        self.font=font
        self.difficulty=''
        if self.game.sight==600:
            self.difficulty='Easy'
        elif self.game.sight==500:
            self.difficulty='Normal'
        elif self.game.sight==400:
            self.difficulty='Hard'
    def update(self,game):
        self.medkit=game.p.inventory.count('medkit')
        self.ammo=game.p.ammo
        self.hp=game.p.hp
        self.remain=game.goal-game.kill_score
        if self.remain<=0:
            self.remain=0
        self.kill=game.kill_score
        self.score=game.score
    def stats_show(self,num,x,y,screen):
        a=self.font.render(str(num),True,(255,255,255))
        a_rect=a.get_rect()
        a_rect.right=x
        a_rect.bottom=y
        screen.blit(a,a_rect)
    def show(self,screen):
        screen.blit(self.image,(0,0))
        pygame.draw.rect(screen,(0,255,0),[90,256,self.hp*2,self.game.pixel])
        self.stats_show(self.hp,85,285,screen)
        self.stats_show(self.ammo,290,490,screen)
        self.stats_show(self.medkit,145,490,screen)
        self.stats_show(self.score,285,608,screen)
        self.stats_show(self.kill,185,572,screen)
        self.stats_show(self.remain,232,572,screen)
        self.stats_show(self.difficulty,282,532,screen)


        
class Game:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption('alone')
        self.pixel=25 
        self.width=1025
        self.height=725
        self.sight=600
        self.screen=pygame.display.set_mode((self.width,self.height))
        self.gameRun=True
        self.run=True
        self.clock=pygame.time.Clock()
        self.p=Player(300+self.height/2-self.pixel/2,self.height/2-self.pixel/2,self.pixel,self)
        self.chunklst=[]
        self.element_lst=[]
        self.mob_lst=[]
        self.bullet_lst=[]
        self.k=False
        self.player_turn=True
        self.mob_turn=False
        self.kill_score=0
        self.game_font=pygame.font.Font('assets/neodgm_pro.ttf',30)
        self.intro_font=pygame.font.Font('assets/neodgm_pro.ttf',80)
        self.score_font=pygame.font.Font('assets/neodgm_pro.ttf',50)
        self.result='none'
        self.score=0
        self.highScore=False
        self.real_high=0

    def intro(self):
        c=Control(self)
        stage=0
        select=0
        while self.gameRun:
            for event in pygame.event.get():
                if event.type==pygame.QUIT:
                    self.gameRun=False
                elif stage<2 and event.type==pygame.KEYDOWN and event.key==pygame.K_RETURN:
                    stage+=1
                elif stage==1 and event.type==pygame.KEYDOWN:
                    if event.key==pygame.K_s:
                        select+=1
                    elif event.key==pygame.K_w:
                        select-=1
                elif stage==3 and event.type==pygame.KEYDOWN and event.key==pygame.K_RETURN:
                    stage=1

            if stage==0:
                self.screen.fill((0,0,0))
                image=pygame.image.load('assets/start.jpg')
                self.screen.blit(image,(0,0))
                alone=self.intro_font.render('Alone',True,(255,255,255))
                self.screen.blit(alone,(440,300))
                enter=self.game_font.render('press Enter to start',True,(0,0,0))
                self.screen.blit(enter,(400,600))
                pygame.display.update()
                self.clock.tick(30)
            elif stage==1:
                self.run=True
                self.screen.fill((0,0,0))
                alone=self.intro_font.render('Difficulty',True,(255,255,255))
                self.screen.blit(alone,(350,100))
                easy=self.intro_font.render('Easy',True,(0,0,0))
                normal=self.intro_font.render('Normal',True,(0,0,0))
                hard=self.intro_font.render('Hard',True,(0,0,0))
                if select%3==0:
                    pygame.draw.rect(self.screen,(255,255,255),[260,200,500,100],10)
                    pygame.draw.rect(self.screen,(255,255,255),[260,350,500,100])
                    pygame.draw.rect(self.screen,(255,255,255),[260,500,500,100])
                    easy=self.intro_font.render('Easy',True,(255,255,255))
                elif select%3==1:
                    pygame.draw.rect(self.screen,(255,255,255),[260,200,500,100])
                    pygame.draw.rect(self.screen,(255,255,255),[260,350,500,100],10)
                    pygame.draw.rect(self.screen,(255,255,255),[260,500,500,100])
                    normal=self.intro_font.render('Normal',True,(255,255,255))
                elif select%3==2:
                    pygame.draw.rect(self.screen,(255,255,255),[260,200,500,100])
                    pygame.draw.rect(self.screen,(255,255,255),[260,350,500,100])
                    pygame.draw.rect(self.screen,(255,255,255),[260,500,500,100],10)
                    hard=self.intro_font.render('Hard',True,(255,255,255))
                self.screen.blit(easy,(430,210))
                self.screen.blit(normal,(390,360))
                self.screen.blit(hard,(430,510))
                instruct=[self.game_font.render('press W to up',True,(255,255,255)),
                        self.game_font.render('press S to down',True,(255,255,255)),
                        self.game_font.render('press Enter to select',True,(255,255,255))]
                self.screen.blit(instruct[0],(840,570))
                self.screen.blit(instruct[1],(810,620))
                self.screen.blit(instruct[2],(730,670))
                pygame.display.update()
                self.clock.tick(30)
            elif stage==2:
                self.screen.fill((0,0,0))
                if select%3==0:
                    #sight/item_spawn/mob_spwan/mob_hp/mob_power/goal/mob_points
                    self.play(600,990,990,10,5,30,100)
                elif select%3==1:
                    self.play(500,990,980,10,10,40,150)
                else:
                    self.play(400,980,960,15,10,50,300)
                stage=3
                pygame.display.update()
                self.clock.tick(30)
            elif stage==3:
                self.screen.fill((0,0,0))
                score=''
                if self.result=='Success':
                    result=pygame.image.load('assets/clear.jpg')
                    self.screen.blit(result,(0,0))
                    score=self.score_font.render('Score: '+str(self.score),True,(255,255,255))

                elif self.result=='Game_over':
                    result=pygame.image.load('assets/over.jpg')
                    self.screen.blit(result,(0,0))
                    score=self.score_font.render('Score: '+str(self.score),True,(255,255,255))
                score_rect=score.get_rect(center=(self.width/2,450))
                self.screen.blit(score,score_rect)
                highs=''
                if self.highScore:
                    highs=self.score_font.render('High Score!',True,(255,255,0))
                else:
                    highs=self.score_font.render('High Score:'+str(self.real_high),True,(255,255,255))
                high_rect=highs.get_rect(center=(self.width/2,520))
                self.screen.blit(highs,high_rect)

                pygame.display.update()
                self.clock.tick(30)
        
    def play(self,range,item_spawn_rate,mob_spawn_rate,mob_hp,mob_attack,goal,mob_points):
        self.sight=range
        self.item_spawn_rate=item_spawn_rate
        self.mob_spawn_rate=mob_spawn_rate
        self.mob_hp=mob_hp
        self.mob_attack=mob_attack
        self.mob_points=mob_points
        self.score=0
        self.p=Player(300+self.height/2-self.pixel/2,self.height/2-self.pixel/2,self.pixel,self)
        self.chunklst=[]
        self.element_lst=[]
        self.mob_lst=[]
        self.bullet_lst=[]
        self.exit_lst=[]
        self.k=False
        self.player_turn=True
        self.mob_turn=False
        self.kill_score=0
        self.goal=goal
        self.result='none'
        self.highScore=False
        self.real_high=0
        c=Control(self)
        status=Status(self,self.game_font)
        #청크 생성
        self.chunkinit()
        self.distance_check()
        while self.run:
            #종료 조건?
            if self.p.hp<=0:
                self.result='Game_over'
                self.run=False
            elif self.result=='Success':
                self.run=False
            #키 획득
            c.turn_check()
            for event in pygame.event.get():
                c.getKey(event,self)
            #player turn
            if self.k:
                self.p.change_direction(self.k) #image change
                if self.p.can_move:
                    self.move_elements(self.k) #move items and mobs
                    self.chunkloader(self.k) #new chunk
                self.player_act(self.k) #player act
                self.distance_check() #distance
            if self.mob_turn:
                self.distance_check()
                self.mob_action()
                
            #인벤토리 업데이트
            status.update(self)
            #검은 배경 업데이트
            self.screen.fill((0,0,0))
            #나머지 요소 표시
            status.show(self.screen)
            self.chunkshow()
            self.element_show()
            self.p.show(self.screen)
            
            pygame.display.update()
            self.k=False
            self.score=10*self.p.action+self.mob_points*self.kill_score

            #기록 저장
            if not self.run:
                if self.result=='Success':
                    self.score+=1000
                with open('assets/record.txt','r') as f:
                    data=f.read()
                    if (len(data)==0):
                        self.highScore=True
                    elif int(data)<=self.score:
                        self.highScore=True
                    else:
                        self.real_high=int(data)
                if self.highScore:
                    with open('assets/record.txt','w+') as f:
                        f.write(str(self.score))
            self.clock.tick(30)    

    def mob_action(self):
        #hp check
        temp=[]
        for i in self.mob_lst:
            if i.hp>0:
                temp.append(i)
            else:
                killed_point=[int((i.x-300)//self.pixel),int(i.y//self.pixel)]
                self.chunklst[killed_point[1]][killed_point[0]].change_image()
                self.kill_score+=1
        self.mob_lst=temp
        #attack
        for i in self.mob_lst:
            i.attack(self.p)
        #move
        self.mob_lst=sorted(self.mob_lst,key=lambda x: dist(x,self.p))
        for i in self.mob_lst:
            i.move(self.p)
        
    
    def player_act(self,k):
        self.p.heal(k) #plus action, heal
        for i in self.element_lst: #pick something
            if i.dist==0:
                self.p.interact(i,k)
        for i in self.exit_lst:
            if i.dist==0:
                self.p.interact(i,k)
        self.p.attack(k,self.bullet_lst,self.mob_lst)

    def distance_check(self):
        for i in self.chunklst:
            for j in i:
                j.dist=dist(self.p,j)
        for i in self.element_lst:
            i.dist=dist(self.p,i)
        for i in self.mob_lst:
            i.dist=dist(self.p,i)
        for i in self.exit_lst:
            i.dist=dist(self.p,i)
    def move_elements(self,k):
        dx=0
        dy=0
        if k==pygame.K_s:
            dy=-self.pixel
        elif k==pygame.K_a:
            dx=self.pixel
        elif k==pygame.K_w:
            dy=self.pixel
        elif k==pygame.K_d:
            dx=-self.pixel
        new_lst=[]
        for i in self.element_lst:
            i.x+=dx
            i.y+=dy
            if (i.x>=300 and i.x<self.width) and (i.y>=0 and i.y<self.height) and i.active:
                new_lst.append(i)
        self.element_lst=new_lst
        new_lst2=[]
        for i in self.mob_lst:
            i.x+=dx
            i.y+=dy
            if (i.x>=300 and i.x<self.width) and (i.y>=0 and i.y<self.height) and i.active:
                new_lst2.append(i)
        self.mob_lst=new_lst2
        new_lst3=[]
        if len(self.exit_lst)>0:
            for i in self.exit_lst:
                i.x+=dx
                i.y+=dy
                if (i.x>=300 and i.x<self.width) and (i.y>=0 and i.y<self.height):
                    new_lst3.append(i)
        self.exit_lst=new_lst3
    
    def element_show(self):
        #delete bullet
        temp2=[]
        for i in self.bullet_lst:
            if i.active:
                temp2.append(i)
        self.bullet_lst=temp2

        for i in self.element_lst:
            if i.active:
                i.show(self.screen)
        for i in self.mob_lst:
            i.show(self.screen)
        for i in self.bullet_lst:
            i.fire(self.screen)
        for i in self.exit_lst:
            i.show(self.screen)

    def chunkinit(self):
        for i in range(self.height//self.pixel):
            self.chunklst.append([])
        for y in range(self.height//self.pixel):
            for x in range(self.height//self.pixel):
                self.chunklst[y].append(Chunk(x*self.pixel+300,y*self.pixel,self.pixel,self))
    def chunkshow(self):
        for j in self.chunklst:
            for i in j:
                i.show(self.screen)
    def chunkloader(self,k):
        length=len(self.chunklst)-1
        if k==pygame.K_w:
            self.chunklst.pop()
            for i in self.chunklst:
                for j in i:
                    j.y+=self.pixel
            self.chunklst.insert(0,[])
            for x in range(self.height//self.pixel):
                self.chunklst[0].append(Chunk(x*self.pixel+300,0,self.pixel,self))
        elif k==pygame.K_a:
            for i in range(len(self.chunklst)):
                self.chunklst[i].pop()
                for j in self.chunklst[i]:
                    j.x+=self.pixel
                self.chunklst[i].insert(0,Chunk(300,i*self.pixel,self.pixel,self))
        elif k==pygame.K_d:
            for i in range(len(self.chunklst)):
                self.chunklst[i].pop(0)
                for j in self.chunklst[i]:
                    j.x-=self.pixel
                self.chunklst[i].append(Chunk(length*self.pixel+300,i*self.pixel,self.pixel,self))
        elif k==pygame.K_s:
            self.chunklst.pop(0)
            for i in self.chunklst:
                for j in i:
                    j.y-=self.pixel
            self.chunklst.append([])
            for x in range(self.height//self.pixel):
                self.chunklst[-1].append(Chunk(x*self.pixel+300,length*self.pixel,self.pixel,self))

                

if __name__=="__main__":
    Game().intro()