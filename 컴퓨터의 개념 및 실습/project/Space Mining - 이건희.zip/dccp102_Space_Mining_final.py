import random
import pygame
import math

white = (255, 255, 255)
black = (0, 0, 0)
magenta =(255, 0, 255)
red = (255, 0, 0)
green = (0, 255, 0)
mint = (0, 255, 255)
blue = (0, 0, 255)

class Player:
    score = 0
    str_score = '0'
    theta = 0
    v = 0
    v_x = 0
    v_y = 0
    dv_x = 0
    dv_y =0
    dtheta = 0
    dv = 0
    alpha = 0
    v_gx = 0
    v_gy = 0
    dv_gx = 0
    dv_gy = 0
    dalpha = 0
    dv_g = 0
    r1 = 5
    r2 = 4
    mass = (r1 + r2)**2
    gravity_on = False
    gravity_time = 0
    def __init__(self, x, y, game, color, life, a, d, w, s, boost):
        self.x = x
        self.x0 = x
        self.y = y
        self.y0 = y
        self.game = game
        self.color = color
        self.life = life
        self.str_life = str(life)
        self.a = a
        self.d = d
        self.w = w
        self.s = s
        self.boost = boost
        self.bool_boost = False
        self.active = True
        self.crash = False
    
    def regenerate(self):
        self.theta = 0
        self.v = 0
        self.v_x = 0
        self.v_y = 0
        self.dv_x = 0
        self.dv_y =0
        self.dtheta = 0
        self.dv = 0
        self.alpha = 0
        self.v_gx = 0
        self.v_gy = 0
        self.dv_gx = 0
        self.dv_gy = 0
        self.dalpha = 0
        self.dv_g = 0
        self.x = self.x0
        self.y = self.y0
        self.gravity_on = False
        self.gravity_time = 0
        
    def handle_event(self, keys):
        if keys[self.a]:
            self.dtheta = -0.05
        elif keys[self.d]:
            self.dtheta = 0.05
        else:
            self.dtheta = 0

        if keys[self.w]:
            self.dv = 0.05
        elif keys[self.s]:
            self.dv = -0.05
        else:
            self.dv = 0
        
        self.dv_x = self.dv * math.cos(self.theta)
        self.dv_y = self.dv * math.sin(self.theta)

        if keys[self.boost]:
            self.bool_boost = True
        else:
            self.bool_boost = False
    
    def tick(self):
        if self.gravity_on == True:
            if self.bool_boost == False:
                self.v_x += self.dv_x
                self.v_y += self.dv_y
            else:
                self.v_x += 2 * self.dv_x
                self.v_y += 2 * self.dv_y
            self.theta += self.dtheta            

            self.x += self.v_x - self.v_gx 
            self.y += self.v_y - self.v_gy

            self.gravity_time -= 1
            if self.gravity_time == 0:
                self.gravity_on = False
                self.v_gx = 0
                self.v_gy = 0
                self.v_x = 0
                self.v_y = 0

        else:
            
            self.v += self.dv
            self.theta += self.dtheta
            if self.bool_boost == True:
                self.x += 1.5*self.v * math.cos(self.theta)
                self.y += 1.5*self.v * math.sin(self.theta)
            else:
                self.x += self.v * math.cos(self.theta)
                self.y += self.v * math.sin(self.theta) 

        if self.crash == True:
            self.regenerate()
            self.life -= 1
            self.str_life = str(self.life)
            self.crash = False
              

    def cal_distance(self, other):
        return ((self.x-other.x)**2+(self.y-other.y)**2)**0.5

    def interact(self, other, game):
        if isinstance(other, Planet):
            if self.gravity_on == True:
                self.alpha = math.atan2((self.y - other.y),(self.x - other.x))
                L = self.cal_distance(other)
                self.dv_g = game.gravity * (self.mass*other.mass)/L
                self.dv_gx = self.dv_g*math.cos(self.alpha)
                self.dv_gy = self.dv_g*math.sin(self.alpha)                
                self.v_gx += self.dv_gx
                self.v_gy += self.dv_gy

            if self.cal_distance(other) < other.radius + self.r1:
                self.crash = True

        
        if isinstance(other, Mineral):
            if isinstance(other, Space_junk):
                if self.cal_distance(other) < other.radius * 2**0.5 + self.r2:
                    other.regeneration()
                    self.v = 0
                    self.gravity_on = True
                    self.gravity_time += 5*60

            else:
                if self.cal_distance(other) < other.radius + self.r2:
                    other.regeneration()
                    self.score += other.radius
                    self.str_score = str(self.score)
                else:
                    pass           

        if (0 < self.x < game.display_size*game.n_cols) and (0 < self.y < game.display_size*game.n_rows):
            pass
        else:
            self.crash = True

    def draw(self):
        point1 = [self.x + self.r1*math.cos(self.theta), self.y + self.r1*math.sin(self.theta)]
        point2 = [
            self.x - self.r1*math.cos(self.theta)-self.r2*math.sin(self.theta),
            self.y - self.r1*math.sin(self.theta)+self.r2*math.cos(self.theta)
        ]
        point3 = [
            self.x - self.r1*math.cos(self.theta)+self.r2*math.sin(self.theta),
            self.y - self.r1*math.sin(self.theta)-self.r2*math.cos(self.theta)
        ]
        pygame.draw.polygon(self.game.display, self.color, [point1, point2, point3])


class Planet:
    
    def __init__(self, x, y, game, color, radius):
        self.x = x
        self.y = y
        self.game = game
        self.color = color
        self.radius = radius
        self.active = True
        self.mass = radius**3

    def draw(self):
        pygame.draw.circle(self.game.display, self.color, [self.x, self.y], self.radius)
    
    def interact(self, other, game):
        pass

    def tick(self):
        pass

    def handle_event(self, keys):
        pass

class Moving_Planet(Planet):
    def __init__(self, x, y, game, color, radius, System_center_x, System_center_y, v):
        super().__init__(x, y, game, color, radius)
        self.center_x = System_center_x
        self.center_y = System_center_y
        self.v = v
        self.r = (x**2 + y**2)**0.5
        self.theta = 0
        self.mass = radius**3
    def tick(self):
        self.theta += self.v
        self.x = self.center_x + self.r * math.sin(self.theta)
        self.y = self.center_y + self.r * math.cos(self.theta)



class Mineral:    
    dv_g = 0
    dv_gx = 0
    dv_gy = 0
    v_g = 0
    v_gx = 0
    v_gy = 0
    def __init__(self, game):
        self.x = random.randint(0.2*game.display_size*(game.n_cols - 1), 0.8*game.display_size*(game.n_cols - 1))
        self.y = random.randint(0.2*game.display_size*(game.n_rows - 1), 0.8*game.display_size*(game.n_rows - 1))
        self.v_x = random.uniform(-1.5, 1.5)
        self.v_y = random.uniform(-1.5, 1.5)
        self.radius = random.randint(3, 6)
        self.game = game
        self.color = (random.randint(0,255),random.randint(0,255),random.randint(0,255))
        self.mass = self.radius**2
        self.active = True

    def handle_event(self, event):
        pass

    def regeneration(self):
        self.x = random.randint(0.2*self.game.display_size*(self.game.n_cols - 1), 0.8*self.game.display_size*(self.game.n_cols - 1))
        self.y = random.randint(0.2*self.game.display_size*(self.game.n_rows - 1), 0.8*self.game.display_size*(self.game.n_rows - 1))
        self.v_x = random.uniform(-3.0, 3.0)
        self.v_y = random.uniform(-3.0, 3.0)
        self.dv_g = 0
        self.dv_gx = 0
        self.dv_gy = 0
        self.v_g = 0
        self.v_gx = 0
        self.v_gy = 0       
    
    def tick(self):

        self.x += self.v_x - self.v_gx 
        self.y += self.v_y - self.v_gy

    def interact(self, other, game):
        if isinstance(other, Planet):
            self.alpha = math.atan2((self.y - other.y),(self.x - other.x))
            L = self.cal_distance(other)
            self.dv_g = game.gravity * (self.mass*other.mass)/L
            
            self.dv_gx = self.dv_g*math.cos(self.alpha)
            self.dv_gy = self.dv_g*math.sin(self.alpha)                
            self.v_gx += self.dv_gx
            self.v_gy += self.dv_gy


            if self.cal_distance(other) < self.radius + other.radius:
                self.regeneration()

    def cal_distance(self, other):
        return ((self.x-other.x)**2+(self.y-other.y)**2)**0.5

    def draw(self):
        pygame.draw.circle(self.game.display, self.color, [self.x , self.y], self.radius)

class Space_junk(Mineral):
    def __init__(self, game):
        super().__init__(game)
        self.radius = random.randint(7,10)
    
    def draw(self):
        self.block_size = self.radius
        self.color = red
        pygame.draw.rect(self.game.display, self.color, [self.x , self.y, self.block_size, self.block_size])


class Game:
    display_size = 10
    gravity = 10**(-5)
    life = 3
    escape = False
    restart = False
    esc = False
    def __init__(self, n_cols, n_rows):
        pygame.init()
        pygame.display.set_caption('dccp102 Space Mining')
        self.display = pygame.display.set_mode((n_cols * self.display_size, n_rows * self.display_size))
        self.font = pygame.font.SysFont('arial', 20, True)
        self.font2 = pygame.font.SysFont('arial', 40)
        self.n_rows = n_rows
        self.n_cols = n_cols
        self.clock = pygame.time.Clock()
        self.game_over = False
        self.SpaceBar = False
        self.x = self.display_size*n_cols
        self.y = self.display_size*n_rows
    
    def play(self, n_minerals = 20):
        self.objects = [ 
            Player(40, self.y/2, self, white, self.life, pygame.K_a, pygame.K_d, pygame.K_w, pygame.K_s, pygame.K_SPACE),
            Planet(self.x/2, self.y/2, self, red, 20),
            Moving_Planet(self.x/5, self.y/5, self, red, 20, self.x/2, self.y/2, 0.01),
            *[Mineral(self) for _ in range(n_minerals)],
            *[Space_junk(self) for _ in range(n_minerals//2)]

        ]


        while not self.game_over:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.game_over = True
                    self.esc = True
                    break

            keys = pygame.key.get_pressed()
            for obj in self.objects:
                if obj.active:
                    obj.handle_event(keys)
                       
            for obj1 in self.objects:
                for obj2 in self.objects:
                    if obj1 != obj2:
                        if obj1.active and obj2.active:
                            obj1.interact(obj2, self)
                            obj2.interact(obj1, self)

            for obj in self.objects:
                if obj.active:
                    obj.tick()
 

            self.display.fill(black)
            for obj in self.objects:
                if obj.active:
                    obj.draw()
            self.score_text = self.font.render('Score: ' + self.objects[0].str_score + '   Life: ' + self.objects[0].str_life, True, white, black)
            self.display.blit(self.score_text, (10, 10))
            pygame.display.update()
            if self.objects[0].life == 0:
                self.game_over = True
                while (self.escape == False) and (self.restart == False) and (self.esc == False):
                    self.ending_text = self.font2.render('Press Y to restart, N to quit', True, white, black)
                    self.display.blit(self.ending_text, (10, 30))
                    pygame.display.update()
                    for event in pygame.event.get():
                        if event.type == pygame.KEYDOWN:
                            if event.key == pygame.K_n:
                                self.escape = True
                            elif event.key == pygame.K_y:
                                self.restart = True
                        elif event.type == pygame.QUIT:
                            self.esc = True


            self.clock.tick(60)


if __name__ == '__main__':

    while True:
        game = Game(n_cols = 130, n_rows=90)
        game.play()
        if (game.esc == True) or (game.escape == True):
            break
        elif game.restart == True:
            pass


