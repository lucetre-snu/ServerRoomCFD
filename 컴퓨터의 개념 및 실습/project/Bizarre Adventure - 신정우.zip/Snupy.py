import pygame
import random

WINDOW_WIDTH = 1200
WINDOW_HEIGHT = 800

BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
FPS = 60

Font = './design/font/HoonWhitecatR.ttf'

boss_occur = 30  #killed cats(enemies) == n일때 boss 등장
occur_prob = 30  #enemy 등장 빈도(작을수록 빈도 증가)

class SNUpy(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load('./design/image/SNUpy.png')
        self.rect = self.image.get_rect()
        self.rect.x = self.rect.width
        self.rect.y = int(WINDOW_HEIGHT/2)
        self.dx = 0
        self.dy = 0
        self.speed = 7
        self.bullets = pygame.sprite.Group()
        self.shield_exist = False
        self.time = 0

        self.shield_image = pygame.image.load('./design/image/snupy_shield.png')
        self.shield_rect = self.shield_image.get_rect()
        self.remaining_shield = 5
        self.shield_time = 60

    def update(self):
        if self.rect.x < 0:
            self.rect.x += self.speed
        elif self.rect.x + self.rect.width > WINDOW_WIDTH:
            self.rect.x -= self.speed
        elif self.rect.y < 0:
            self.rect.y += self.speed
        elif self.rect.y + self.rect.height > WINDOW_HEIGHT:
            self.rect.y -= self.speed
        elif self.shield_exist == True:
            self.shield()        
            
    def move(self):    
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            if key[pygame.K_UP]:
                self.rect.x -= self.speed
                self.rect.y -= self.speed
            elif key[pygame.K_DOWN]:
                self.rect.x -= self.speed
                self.rect.y += self.speed
            else:
                self.rect.x -= self.speed
        elif key[pygame.K_RIGHT]:
            if key[pygame.K_UP]:
                self.rect.x += self.speed
                self.rect.y -= self.speed
            elif key[pygame.K_DOWN]:
                self.rect.x += self.speed
                self.rect.y += self.speed
            else:
                self.rect.x += self.speed
        elif key[pygame.K_UP]:
            self.rect.y -= self.speed
        elif key[pygame.K_DOWN]:
            self.rect.y += self.speed

    def skill(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                bullet = Snupy_Bullet(self.rect.x+self.rect.width, self.rect.centery, 2*self.speed)
                bullet.launch()
                self.bullets.add(bullet)
            elif event.key == pygame.K_f:
                if self.remaining_shield > 0:
                    self.shield()
                    self.remaining_shield -=1

    def shield(self):
        self.shield_exist = True
        self.time += 1
        if self.time > self.shield_time:
            self.shield_exist = False
            self.time = 0
        elif self.time % 2 == 1:
            self.shield_rect.x = self.rect.x-17
            self.shield_rect.y = self.rect.y-35
            screen.blit(self.shield_image, self.shield_rect)

    def draw(self, screen):
        screen.blit(self.image, self.rect)
    
    def collision(self, enemies, enemy_bullets, boss):
        if self.shield_exist == False:
            for sprite in enemies:
                if pygame.sprite.collide_rect(self, sprite):
                    return sprite
            for sprite in enemy_bullets:
                if pygame.sprite.collide_rect(self, sprite):
                    return sprite
            if pygame.sprite.collide_rect(self, boss):
                return boss

class Enemy1(pygame.sprite.Sprite):
    image = './design/image/Enemy1.png'
    hp_value = 2
    def __init__(self):
        super().__init__()
        self.image = pygame.image.load(self.image)
        self.rect = self.image.get_rect()
        self.rect.x = WINDOW_WIDTH
        self.rect.y = random.randint(0, WINDOW_HEIGHT - self.rect.height)
        self.speed = 1
        self.hp = self.hp_value

    def move(self):
        self.rect.x -= self.speed
        if self.rect.x < WINDOW_WIDTH - self.rect.width:    
            self.speed = 20

    def out_of_screen(self):
        if self.rect.x < 0 or self.rect.y>WINDOW_HEIGHT or self.rect.y + self.rect.height<0:
            self.kill()

    def update(self):
        self.move()
        self.out_of_screen()
    
class Enemy2(Enemy1):
    image = './design/image/Enemy2.png'
    hp_value = 3
    def __init__(self, speed, enemy_bullets):
        super().__init__()
        self.speed = speed
        self.enemy_bullets = enemy_bullets
        self.time=0
        self.dy=0

    def attack(self):
        self.time+=1
        if self.time % 120 == 1:
            bullet = Enemy_Bullet(self.rect.x, self.rect.centery, int(2*self.speed))
            bullet.launch()
            self.enemy_bullets.add(bullet)

    def move(self):
        self.rect.x -= self.speed
        self.rect.y += self.dy
        y=random.randint(1,2)
        if self.time % 60 ==1:    
            if y == 1:
                self.dy += self.speed
            else:
                self.dy -= self.speed

    def update(self):
        self.attack()
        self.move()
        self.out_of_screen()

class Boss(Enemy2):
    image = './design/image/Boss.png'
    hp_value = 60
    def __init__(self, speed, enemy_bullets):
        super().__init__(speed, enemy_bullets)
        self.rect.y=int(WINDOW_HEIGHT/2)-int(self.rect.height/2)
        self.attacked = 0
        self.dx = 0
        self.dy = self.speed
        self.bullet_speed = 5
        self.sound = pygame.mixer.Sound('./design/sound/boss_bullet.wav')
        self.arrive = False

    def attack(self):
        self.time+=1
        if self.time % 90 == 1:
            bullet1 = Boss_Bullet(self.rect.x - 20, self.rect.centery, self.bullet_speed)
            bullet2 = Boss_Bullet(self.rect.x + self.rect.width - 150, self.rect.centery - 30, self.bullet_speed)
            bullet1.launch()
            bullet2.launch()
            self.enemy_bullets.add(bullet1)
            self.enemy_bullets.add(bullet2)

    def move(self):
        self.attack()
        if self.arrive == False:
            if self.rect.x + self.rect.width + 100 > WINDOW_WIDTH:
                self.dx = -self.speed
            else:
                self.arrive = True
        if self.arrive == True:
            if self.rect.x + self.rect.width + 100 < WINDOW_WIDTH:
                self.dx = 1
            elif self.rect.x + self.rect.width > WINDOW_WIDTH:
                self.dx = -1
        draw_text('Boss HP : {}'.format(self.hp), int(WINDOW_WIDTH/2), 40, 30)

    def update(self):
        if self.rect.y < 0:
            self.dy = self.speed
        elif self.rect.y + self.rect.height > WINDOW_HEIGHT:
            self.dy = -self.speed
        self.rect.x += self.dx
        self.rect.y += self.dy
    
    def collision(self, sprites):
        for sprite in sprites:
            if pygame.sprite.collide_rect(self, sprite):
                self.attacked+=1
                sprite.kill()
                self.hp -= 1
                return sprite

    def draw(self, screen):
        screen.blit(self.image, self.rect)

class Bullet(pygame.sprite.Sprite):
    image = 'image'
    sound = 'sound'
    def __init__(self, x, y, speed):
        super().__init__()
        self.image = pygame.image.load(self.image)
        self.sound = pygame.mixer.Sound(self.sound)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed = speed

    def launch(self):
        self.sound.play()

class Snupy_Bullet(Bullet):
    image = './design/image/Snupy_bullet.png'
    sound = './design/sound/snupy_bullet.wav'

    def update(self):
        self.rect.x += self.speed
        if self.rect.x + self.rect.width > WINDOW_WIDTH:
            self.kill()

    def collision(self, sprites):
        for sprite in sprites:
            if pygame.sprite.collide_rect(self, sprite):
                sprite.hp -= 1
                self.kill()
                if sprite.hp == 0:
                    return sprite

class Enemy_Bullet(Bullet):
    image = './design/image/Enemy_bullet.png'
    sound = './design/sound/cat_bullet.wav'

    def update(self):
        self.rect.x -= self.speed
        if self.rect.x < 0:
            self.kill()

class Boss_Bullet(Enemy_Bullet):
    image = './design/image/boss_bullet.png'
    sound = './design/sound/boss_bullet.wav'

class Explosion(pygame.sprite.Sprite):
    image = './design/image/explosion.png'
    def __init__(self, x, y, time):
        super().__init__()
        self.image = pygame.image.load(self.image)
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.time=time
        self.zero = 0
        
    def update(self):
        self.zero+=1
        if self.zero > self.time:
            self.kill()

class Snupy_Explosion(Explosion):
    image = './design/image/snupy_explosion.png'

class Boss_Explosion(Explosion):
    image = './design/image/boss_explosion.png'

def draw_text(text, x, y, scale):
    font = pygame.font.Font(Font, scale)
    color = BLACK
    surface = screen
    text = font.render(text, True, color)
    text_rect = text.get_rect()
    text_rect.centerx = x
    text_rect.centery = y
    surface.blit(text, text_rect)

def game_loop():
    background_image = pygame.image.load('./design/image/background.png')
    fps_clock = pygame.time.Clock()

    enemies = pygame.sprite.Group()
    explosions = pygame.sprite.Group()
    enemy_bullets = pygame.sprite.Group()
    snupy = SNUpy()
    boss= Boss(2, enemy_bullets)

    game_over = False
    game_won = False
    shot_count = 0
    time = 0
    game_over_time=0

    while True:
        if game_over == True:
            game_over_time+=1
            if game_over_time>40:
                return 'game_over'
        elif game_won == True:
            game_over_time+=1
            if game_over_time>30:
                return 'game_won'
        #Game over decision
        elif snupy.collision(enemies, enemy_bullets, boss):
            e=Snupy_Explosion(snupy.rect.x-30, snupy.rect.y-40, 40)
            explosions.add(e)
            game_over = True
        else:
                #Event handling
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    return 'quit'       
                snupy.skill(event)
            snupy.move()
                
            screen.blit(background_image, background_image.get_rect())

            #Loop according to boss_occur
            if shot_count >= boss_occur:
                time+=1
                if time < 120:
                    draw_text('Here Comes Boss!!!', int(WINDOW_WIDTH/2), int(WINDOW_HEIGHT/3), 60)
                boss.move()
                occur_of_enemies = 1 + int((boss.hp_value - boss.hp)/(boss.hp_value-20))                  
                if random.randint(1, 2*occur_prob) == 1:    #Enemy2 생성
                    for _ in range(occur_of_enemies):
                        speed = random .randint(2,3)
                        enemy = Enemy2(speed, enemy_bullets)
                        enemies.add(enemy)
                elif random.randint(1, 3*occur_prob) == 1:  #Enemy1 생성
                    for _ in range(2*occur_of_enemies):
                        enemy = Enemy1()
                        enemies.add(enemy)  

                bul=boss.collision(snupy.bullets)           #Interaction b/w Boss & Snupy Bullet
                if bul:
                    e=Explosion(bul.rect.x+bul.rect.width, bul.rect.y, 20)
                    explosions.add(e)        
                if boss.hp == 0:
                    boss.kill()
                    e=Boss_Explosion(boss.rect.x-50, boss.rect.y-100, 30)
                    explosions.add(e)
                    game_won = True

            else:
                occur_of_enemies = 1 + int(shot_count/15)
                if random.randint(1, occur_prob) == 1:
                    for _ in range(occur_of_enemies):
                        speed = random.randint(2,5)
                        enemy = Enemy2(speed, enemy_bullets)
                        enemies.add(enemy) 
                elif random.randint(1, 4*occur_prob) == 1:
                    for _ in range(occur_of_enemies):
                        enemy = Enemy1()
                        enemies.add(enemy)          

            #Enemy kill decision
            for bullet in snupy.bullets:
                enemy = bullet.collision(enemies)
                if enemy:
                    e=Explosion(enemy.rect.x, enemy.rect.y, 30)
                    explosions.add(e)
                    enemy.kill()
                    shot_count += 1
            #Draw text        
            draw_text('Killed Cats : {}'.format(shot_count),  100, 40, 30)
            draw_text('Ramaining Shields : {}'.format(snupy.remaining_shield), 140, 70, 30)
            
            #Update
            boss.update()
            boss.draw(screen)
            enemies.update()
            enemies.draw(screen)
            snupy.bullets.update()
            snupy.bullets.draw(screen)
            snupy.update()
            snupy.draw(screen)
            enemy_bullets.update()
            enemy_bullets.draw(screen)
        explosions.update()
        explosions.draw(screen)
        pygame.display.flip() 

        fps_clock.tick(FPS)

def game_won():
    x = int(WINDOW_WIDTH/2)
    y = int(WINDOW_HEIGHT/3)
    start_image = pygame.image.load('./design/image/background.png')
    screen.blit(start_image, [0,0])

    draw_text('Congratulations!!!', x, y, 50)
    draw_text('You Won the Cats!!!', x, y+50, 50)
    draw_text('Press Enter to', x, y+150, 30)
    draw_text('Go to the Menu', x, y+200, 30)

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                return 'menu'
        if event.type == pygame.QUIT:
            return 'quit'
    
    return 'game_won'

def game_over():
    x = int(WINDOW_WIDTH/2)
    y = int(WINDOW_HEIGHT/3)
    start_image = pygame.image.load('./design/image/background.png')
    screen.blit(start_image, [0,0])

    draw_text('You Are Dead', x, y, 50)
    draw_text('Press Enter to', x, y+150, 30)
    draw_text('Go to the Menu', x, y+200, 30)

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                return 'menu'
        if event.type == pygame.QUIT:
            return 'quit'
    
    return 'game_over'

def menu():
    x = int(WINDOW_WIDTH/2)
    y = int(WINDOW_HEIGHT/3)
    start_image = pygame.image.load('./design/image/background.png')
    screen.blit(start_image, [0,0])
    screen.blit(pygame.image.load('./design/image/up.png'), [x+int(3*x/5)-35,y+130])
    screen.blit(pygame.image.load('./design/image/down.png'), [x+int(3*x/5)-35,y+200])
    screen.blit(pygame.image.load('./design/image/left.png'), [x+int(3*x/5)-50-55,y+199])
    screen.blit(pygame.image.load('./design/image/right.png'), [x+int(3*x/5)-50+87,y+199])
    screen.blit(pygame.image.load('./design/image/space.png'), [int(x/9)+10, y+130])
    screen.blit(pygame.image.load('./design/image/shield.png'), [int(x/3) + 7, y+260])

    draw_text('SNU.py\'s Bizarre Adventure', x, y, 50)
    draw_text('Press Enter to', x, y+150, 30)
    draw_text('Start Game', x, y+200, 30)
    draw_text('Tip1 : Cats never die with a Single Bullet!', x, y+300, 20)
    draw_text('Tip2 : If you kill {} Cats, Boss will find you!'.format(boss_occur), x, y+330, 20)
    draw_text('Move', x+int(3*x/5), y+100, 30)
    draw_text('Shoot', x-int(3*x/5), y+100, 30)
    draw_text('Shield', x-int(3*x/5), y+230, 30)

    pygame.display.update()

    for event in pygame.event.get():
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                return 'play'
        if event.type == pygame.QUIT:
            return 'quit'

    return 'menu'

def main():
    global screen

    pygame.init()
    screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
    pygame.display.set_caption('SNU.py\'s Bizarre Adventure')
    pygame.mixer.music.load('./design/sound/Gamma Skies-Love Out Loud.wav')
    pygame.mixer.music.play(-1)

    action = 'menu'
    while action != 'quit':
        if action == 'menu':
            action = menu()
        elif action == 'play':
            action = game_loop()
        elif action == 'game_won':
            action = game_won()
        elif action == 'game_over':
            action = game_over()

    pygame.QUIT

if __name__ == '__main__':
    main()