import turtle as t
from data import DATA_CSE, DATA_YOUTUBE

def tree_map(box_range, data):
    # === ENTER YOUR CODE ===
    x1, x2, y1, y2 = box_range
    # === END OF YOUR CODE ===

if __name__ == "__main__":
    t.speed(0)
    box_range = (-550, 550, -350, 350)
    # 아래의 두 줄 중 하나를 주석 해제하세요
    # tree_map(box_range, DATA_CSE)
    # tree_map(box_range, DATA_YOUTUBE)
    t.exitonclick()